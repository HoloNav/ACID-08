import {AcidVoice} from '../synth/acid-voice.js';
import {DrumEngine} from '../drums/drum-engine.js';
import {Effects} from '../synth/effects.js';
export class AudioEngine {
  constructor(ctx,project){
    this.ctx=ctx;this.project=project;
    this.bassBus=ctx.createGain();this.drumBus=ctx.createGain();this.bassBus.gain.value=1;this.drumBus.gain.value=1;
    this.mix=ctx.createGain();this.mix.gain.value=0.77;
    this.effects=new Effects(ctx,this.mix,project.mixer);
    this.bassBus.connect(this.mix);this.drumBus.connect(this.mix);
    this.bassBus.connect(this.effects.delayInput);this.drumBus.connect(this.effects.delayInput);
    this.bassBus.connect(this.effects.reverbInput);this.drumBus.connect(this.effects.reverbInput);
    this.voice=new AcidVoice(ctx,this.bassBus,project.synth);
    this.drums=new DrumEngine(ctx,this.drumBus,project.mixer.drumLevels);
    this.compressor=ctx.createDynamicsCompressor();this.compressor.threshold.value=-7;this.compressor.knee.value=6;this.compressor.ratio.value=6;this.compressor.attack.value=0.004;this.compressor.release.value=0.13;
    this.output=ctx.createGain();this.output.gain.value=1;
    this.mix.connect(this.compressor);this.compressor.connect(this.output);this.output.connect(ctx.destination);
    this.updateProject(project);
  }
  updateProject(project){this.project=project;this.voice.setParams(project.synth);this.drums.setLevels(project.mixer.drumLevels);this.effects.set(project.mixer);
    const t=this.ctx.currentTime;this.bassBus.gain.setTargetAtTime(project.mixer.bassMute?0:1,t,0.015);this.drumBus.gain.setTargetAtTime(project.mixer.drumMute?0:1,t,0.015);
    this.mix.gain.setTargetAtTime(0.2+(project.mixer.master*0.6),t,0.012);
  }
  scheduleStep(pattern,index,time,duration,stepNumber=0){
    const b=pattern.tracks.bass,step=b[index],prev=b[(index+31)%32],next=b[(index+1)%32];
    if(step.on){
      const nextDuration=60/this.project.tempo/2-duration;
      const gateLength=step.tie&&!next.on?duration+nextDuration*0.85:duration;
      this.voice.trigger(step.note,time,gateLength,{accent:step.accent,legato:stepNumber>0&&prev.on&&(prev.slide||prev.tie),hold:next.on&&(step.slide||step.tie)});
    }
    for(const name of ['kick','snare','clap','tom','closedHat','openHat']){
      const s=pattern.tracks[name][index];
      if(s.on&&this.passProbability(s.probability,stepNumber,name))this.drums.trigger(name,time);
    }
  }
  passProbability(prob,stepNumber,name){
    if(prob>=100)return true;if(prob<=0)return false;
    // Deterministic hash: offline render matches live decisions for corresponding pass.
    let id=0;for(let i=0;i<name.length;i++)id=Math.imul(id+name.charCodeAt(i),31)>>>0;let h=((stepNumber+1)*2654435761+id)>>>0;h=Math.imul(h^(h>>>16),2246822519)>>>0;
    return h%100<prob;
  }
  click(time,strong=false){const ctx=this.ctx,osc=ctx.createOscillator(),g=ctx.createGain();osc.type='sine';osc.frequency.value=strong?1150:850;
    g.gain.setValueAtTime(0.11,time);g.gain.exponentialRampToValueAtTime(0.0001,time+0.048);osc.connect(g);g.connect(this.mix);osc.start(time);osc.stop(time+0.06);
  }
  testTone(){const t=this.ctx.currentTime+0.01;this.voice.silence(t);this.voice.trigger(36,t,0.33,{accent:true});}
  panic(){const t=this.ctx.currentTime;this.voice.silence(t);this.output.gain.cancelScheduledValues(t);this.output.gain.setValueAtTime(0,t);}
  unpanic(){this.output.gain.cancelScheduledValues(this.ctx.currentTime);this.output.gain.setTargetAtTime(1,this.ctx.currentTime,0.006);}
  dispose(){this.panic();this.voice.dispose();}
}
export async function initializeLiveAudio(project){
  const AudioContextClass=window.AudioContext||window.webkitAudioContext;
  if(!AudioContextClass)throw new Error('This browser does not support Web Audio API.');
  let ctx;
  try{ctx=new AudioContextClass({latencyHint:'interactive'});await ctx.resume();if(ctx.state!=='running')throw new Error(`Audio context state is ${ctx.state}`);return {ctx,engine:new AudioEngine(ctx,project)};}
  catch(error){if(ctx)await ctx.close().catch(()=>{});throw new Error(`Audio initialization failed: ${error.message}`);}
}
