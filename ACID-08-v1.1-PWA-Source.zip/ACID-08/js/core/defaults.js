export const TRACKS = ['bass', 'kick', 'snare', 'clap', 'tom', 'closedHat', 'openHat'];
export const DRUMS = TRACKS.slice(1);
export const LABELS = {bass:'ACID BASS',kick:'KICK',snare:'SNARE',clap:'CLAP',tom:'TOM',closedHat:'CL HAT',openHat:'OP HAT'};
export const SYNTH_DEFAULTS = {level:0.68,pitch:0,decay:0.46,cutoff:0.38,resonance:0.73,envMod:0.77,accent:0.65,slide:0.57,wave:'saw',filterMode:'lowpass'};
export const MIX_DEFAULTS = {master:0.77,delay:0.16,reverb:0.13,delayFeedback:0.31,bassMute:false,drumMute:false,metronome:false,drumLevels:{kick:0.85,snare:0.68,clap:0.6,tom:0.62,closedHat:0.49,openHat:0.47}};
const bassStep = () => ({on:false,note:36,accent:false,slide:false,tie:false});
const drumStep = () => ({on:false,probability:100});
export function createPattern() {
  const tracks = {};
  for (const track of TRACKS) tracks[track] = Array.from({length:32},()=>track==='bass'?bassStep():drumStep());
  return {tracks};
}
export function createProject() {
  const patterns = Array.from({length:16},createPattern);
  const p = patterns[0].tracks;
  const bassNotes = {0:36,3:36,6:39,8:36,10:43,12:39,14:34,16:36,19:36,22:41,24:39,27:43,28:36,30:34};
  for (const [i,note] of Object.entries(bassNotes)) {p.bass[i].on=true;p.bass[i].note=note;}
  for (const i of [3,10,14,19,27,30]) p.bass[i].accent=true;
  for (const i of [6,22,27]) p.bass[i].slide=true;
  for (const i of [8,24]) p.bass[i].tie=true;
  for (let i=0;i<32;i++) {
    if(i%4===0) p.kick[i].on=true;
    if(i%8===4) {p.snare[i].on=true;p.clap[i].on=true;}
    if(i%2===0) p.closedHat[i].on=true;
    if(i%16===14) p.openHat[i].on=true;
  }
  p.tom[30].on=true;
  return {version:1,name:'ACID-08 Demo',tempo:126,swing:0.09,selectedPattern:0,synth:{...SYNTH_DEFAULTS},mixer:{...MIX_DEFAULTS,drumLevels:{...MIX_DEFAULTS.drumLevels}},patterns,updatedAt:new Date().toISOString()};
}
const clamp=(n,min,max)=>Math.max(min,Math.min(max,n));
export function normalizeProject(obj) {
  if(!obj || typeof obj!=='object' || !Array.isArray(obj.patterns)) throw new Error('Not an ACID-08 project (patterns missing).');
  const p=createProject();
  p.name=String(obj.name||'Imported Project').slice(0,80);
  p.tempo=clamp(Number(obj.tempo)||126,60,240);
  p.swing=clamp(Number(obj.swing)||0,0,0.45);
  p.selectedPattern=clamp(Math.trunc(Number(obj.selectedPattern)||0),0,15);
  for(const k of Object.keys(SYNTH_DEFAULTS)) {
    if(k==='wave')p.synth[k]=obj.synth?.[k]==='square'?'square':'saw';
    else if(k==='filterMode')p.synth[k]=obj.synth?.[k]==='bandpass'?'bandpass':'lowpass';
    else p.synth[k]=clamp(Number(obj.synth?.[k] ?? SYNTH_DEFAULTS[k])||0,k==='pitch'?-12:0,k==='pitch'?12:1);
  }
  for(const k of ['master','delay','reverb','delayFeedback'])p.mixer[k]=clamp(Number(obj.mixer?.[k]??MIX_DEFAULTS[k])||0,0,1);
  for(const k of ['bassMute','drumMute','metronome'])p.mixer[k]=Boolean(obj.mixer?.[k]);
  for(const d of DRUMS)p.mixer.drumLevels[d]=clamp(Number(obj.mixer?.drumLevels?.[d]??MIX_DEFAULTS.drumLevels[d])||0,0,1);
  for(let j=0;j<16;j++)for(const track of TRACKS)for(let i=0;i<32;i++) {
    const src=obj.patterns?.[j]?.tracks?.[track]?.[i];
    const dst=p.patterns[j].tracks[track][i];
    if(!src || typeof src!=='object') { if(j===0)Object.assign(dst,track==='bass'?bassStep():drumStep());continue; }
    dst.on=Boolean(src.on);
    if(track==='bass') {dst.note=clamp(Math.trunc(Number(src.note)||36),24,84);for(const flag of ['accent','slide','tie'])dst[flag]=Boolean(src[flag]);}
    else dst.probability=clamp(Math.trunc(Number(src.probability??100)),0,100);
  }
  p.updatedAt=new Date().toISOString();return p;
}
