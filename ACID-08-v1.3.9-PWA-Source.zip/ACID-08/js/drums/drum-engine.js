import {makeNoiseBuffer} from './shared.js';
import {kick} from './kick.js';
import {snare} from './snare.js';
import {clap} from './clap.js';
import {tom} from './tom.js';
import {hat} from './hat.js';

// Equal slider positions used to favor the kick and practically bury the clap,
// snare and hats. These fixed voice trims improve balance without modifying
// the project's saved slider values or requiring a data migration.
const VOICE_GAIN = Object.freeze({
  kick:0.80, snare:1.65, clap:2.65, tom:0.95,
  closedHat:1.50, openHat:1.45
});

export class DrumEngine {
  constructor(ctx,destination,levels){
    this.ctx=ctx;
    this.noise=makeNoiseBuffer(ctx);
    this.nodes={};
    for(const id of Object.keys(VOICE_GAIN)){
      const gain=ctx.createGain();
      gain.gain.value=(levels[id]??0.7)*VOICE_GAIN[id];
      gain.connect(destination);
      this.nodes[id]=gain;
    }
    this.openHat=null;
  }
  setLevels(levels){
    for(const [id,level] of Object.entries(levels)){
      if(this.nodes[id])this.nodes[id].gain.setTargetAtTime(level*VOICE_GAIN[id],this.ctx.currentTime,0.015);
    }
  }
  trigger(id,time,velocity=1){
    const t=Math.max(this.ctx.currentTime,time),dest=this.nodes[id];
    if(!dest)return;
    if(id==='kick')kick(this.ctx,dest,this.noise,t,velocity);
    if(id==='snare')snare(this.ctx,dest,this.noise,t,velocity);
    if(id==='clap')clap(this.ctx,dest,this.noise,t,velocity);
    if(id==='tom')tom(this.ctx,dest,this.noise,t,velocity);
    if(id==='openHat')this.openHat=hat(this.ctx,dest,this.noise,t,velocity,true);
    if(id==='closedHat'){
      if(this.openHat)this.openHat.choke(t);
      hat(this.ctx,dest,this.noise,t,velocity,false);
    }
  }
}
