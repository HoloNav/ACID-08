import {noiseSource} from './shared.js';
export function clap(ctx,dest,noise,time,vel=1){
  const src=noiseSource(ctx,noise),bp=ctx.createBiquadFilter(),hp=ctx.createBiquadFilter(),env=ctx.createGain();
  bp.type='bandpass';bp.frequency.value=1350;bp.Q.value=0.8;hp.type='highpass';hp.frequency.value=550;
  const g=env.gain;g.setValueAtTime(0.0001,time);
  for(let i=0;i<3;i++){const t=time+i*0.014;g.setValueAtTime(0.0001,t);g.linearRampToValueAtTime((0.74-i*0.08)*vel,t+0.002);g.exponentialRampToValueAtTime(0.0001,t+0.012);}
  g.setValueAtTime(0.42*vel,time+0.048);g.exponentialRampToValueAtTime(0.0001,time+0.22);
  src.connect(bp);bp.connect(hp);hp.connect(env);env.connect(dest);src.start(time);src.stop(time+0.25);
}
