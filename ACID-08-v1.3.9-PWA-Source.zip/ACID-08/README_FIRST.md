# ACID-08 v1.3.9 — Acid Groove Machine

An original, standalone, offline-capable PWA acid bass synthesizer and six-voice drum machine. Built using native HTML/CSS, JavaScript ES modules and the Web Audio API. All drums are synthesized, not sampled. No proprietary Roland code, samples or branding are used.

## Quick start — computers

1. Extract the ZIP; keep the directory structure intact.
2. Open a terminal in the **ACID-08** folder.
3. Run `python -m http.server 8080` (or `python3 -m http.server 8080`).
4. In Chrome/Edge open `http://localhost:8080`.
5. Press **POWER** for an acid test tone; press **PLAY** to hear the supplied demo pattern.

Because the app uses JavaScript modules and a service worker, do **not** double-click `index.html` through `file://`. Serve through localhost or HTTPS.

## Install on Android

Host this complete directory on an HTTPS server (e.g. your own static web host or GitHub Pages). Open that HTTPS URL in **Android Chrome**, use Chrome’s menu → **Add to Home screen** / **Install app** (wording varies), and launch from the icon. On supported Android Chrome versions, the manifest requests landscape orientation. PWA installation and offline support require a secure origin (`https://` or localhost). Each app launch requires an audio-enabling tap, by browser design. For local phone testing, deploy to HTTPS; a laptop’s LAN HTTP address may not qualify as a secure context for PWA installation.

## v1.1 — Instrument-first layout (DUAL-01 style)

- Main instrument tabs: **BASS**, **DRUMS**, **SYNTH**, **MIXER**. BASS is the default view on phones and computers.
- **BASS** puts the step grid directly above a large, touchable, two-octave piano keyboard. Select a step, tap a piano key, and it saves the note to that step and auditions it immediately. Accent, slide, tie, page 1/2 and pattern bank stay on the same screen.
- **DRUMS** shows all six independent drum tracks and the performance pads; tap a drum step to toggle its trigger. Select a step to edit its probability.
- **SYNTH** exposes all eight acid bass controls, waveform and filter modes. **MIXER** contains master and FX levels, swing, and mutes.
- Projects and patterns use the same format as v1.0. Saved data is retained when the updated PWA is deployed to the **same** HTTPS address; as a precaution, export a JSON backup before the first update.
- This is a UI update; the underlying sound engine, 16-pattern storage, 32-step transport, and WAV renderer are unchanged.

## Controls

- **POWER** initializes audio and plays a bass test tone.
- **PLAY / STOP** run the audio-clock-based scheduler. **TAP** estimates BPM from taps.
- **Bass programming:** select **ACID BASS** track, tap a step to select it, then tap a piano key. The step activates when you assign a note. Use **ENABLE** to turn it off/on and **ACCENT / SLIDE / TIE** to shape playback. **OCT** selects the keyboard's octave. Select **01–16** or **17–32** to edit page two.
- **Drum programming:** select a drum track and tap a step to toggle the trigger. Select the step and edit its probability.
- **Patterns:** click any of 16 independent slots. The default demo is in slot 01; others start blank. Changing a pattern does not erase the others.
- **Drums:** touch each drum pad to audition that sound; slider controls its level.
- **Knobs:** drag vertically, scroll a mouse wheel, or focus and press arrow keys. PITCH shifts the synth in semitones.
- **SAVE** saves a named local project; it confirms before overwriting an existing name. **LOAD** chooses a saved project. Active work auto-saves as a separate draft in IndexedDB (fallback localStorage).
- **⋮** opens project JSON import/export and reset to demo.
- **↓ WAV** downloads a 44,100 Hz, 16-bit PCM stereo WAV recording of *four bars* of the selected 32-step pattern, repeated twice, plus a **2-second effects tail**. Export uses OfflineAudioContext and the *same synthesis and pattern scheduling modules* as live playback.

## Functional architecture

- `js/core/` audio master, 32-step audio-clock transport, pattern system, IndexedDB library, project validation.
- `js/synth/` acid voice (saw/pulse, resonant VCF, decay envelope, accents, slide/tie), and original stereo delay / generated convolution reverb.
- `js/drums/` six original fully synthesized drum instruments with synthesized noise, tuned oscillators and enveloping.
- `js/ui/` interactive controls, editing UI, pattern selector, keyboard, drum pads.
- `js/export/` offline four-bar rendering and PCM encoding.
- `css/` independent layout and device styles.

## Current implementation notes

- Browser synthesis approximates classic diode-ladder acid behavior using Web Audio's resonant biquad, saturator, and per-step filter envelopes; it is **not** a physical-circuit or transistor-level 303 model. Refining this is the most valuable next audio improvement.
- A monophonic synth oscillator stays running while the context is active. Web Audio timer-lookahead schedules actual events against `AudioContext.currentTime`; UI animation never controls the audio clock.
- A user interaction is required to start or resume sound. Some phones suspend audio when apps are backgrounded; ACID-08 intentionally stops the transport when hidden to avoid an unstable skipped sequence.
- Some lower-end phones may struggle with high-Q resonance, synthesized hats, or convolution reverb; use lower effect sends when needed. AudioWorklet is a future enhancement, **not used in v1.0**; this version uses Web Audio nodes, lookahead scheduling, and offline context.
- The PWA uses a cache-first service worker. When deploying updates, bump the cache string in `service-worker.js` to ensure visitors pick up changes.
- The initial app is not a native APK; it is an installable browser PWA. An Android native audio backend would be a separate phase.
- Storage remains local to the browser and origin and may be cleared by the OS or browser; export JSON for backups.
- Stereo WAV output is 16-bit signed PCM, with the *four-bar performance followed by 2 seconds* for reverb/delay tails. It can sound slightly different from live playback due to device sample rate, offline 44.1 kHz resampling and browser audio implementation.

## Acceptance testing checklist

1. Power once: hear acid tone, engine indicator turns green.
2. Play demo, hear bass + kick/snare/clap + hats + tom.
3. Twist cutoff, resonance, envelope, decay, accent and slide; verify their audible response.
4. Edit a note on page 2; let the sequencer reach it.
5. Edit a drum track, set probability, verify timing and triggering.
6. Switch among patterns 01–16, program separate steps, then switch back; data remains.
7. Close/reopen the browser: auto-saved draft returns.
8. Save named project, reload it. Export/import JSON.
9. Adjust tempo / swing; stop and restart; no stuck bass tone.
10. Download a WAV file, check its PCM header and listen through the effects tail.
11. Install as Android PWA over HTTPS, reload with the network disabled, press Power then Play.

---
Original project: ACID-08. This release is a working browser instrument, not a visual-only mockup. Sounds are original synthesized voices. No proprietary assets required.

## v1.2 — Synth keyboard + distortion

- The **SYNTH** tab now includes a full-size, two-octave live keyboard beneath the knobs (fixed along the bottom on smaller screens). Pressing a key auditions the current patch **without changing any steps**. The BASS tab keyboard still programs selected steps.
- Octave +/- is shared across both keyboards. The SYNTH keyboard triggers a short note and does not require the sequencer to play.
- Added **DISTORTION** (0–100%) to the synthesizer. This is a parallel, pre-gate saturation path immediately after the resonant filter, with smooth wet/dry and drive changes. 0% is clean, and high settings add crunchy clipped harmonics. A level-compensated wet signal helps prevent excessively loud jumps.
- Distortion is stored with each project and applied by the same audio engine during **offline WAV export**. Older saved projects open with distortion at 0%.
- The v1.2 service-worker cache name is updated to ensure the PWA requests new assets after deployment. A JSON export before an app upgrade is still recommended.
- Live audition can interfere with a currently playing monophonic bass sequence; press STOP when designing patches via keys.


## v1.3 — Black/amber + expressive note playback

- **New dark hardware theme:** near-black panels, amber/orange active controls, warm-white labels, and clearly distinguished selected vs. playing steps. The install icons have been recolored to match.
- **TONE (new):** 0–100% controls a smooth highshelf EQ after saturation; 50% is neutral, lower settings darken the sound, and higher settings emphasize gritty high frequencies. It comes before delay/reverb effects. The original **LEVEL** knob is still present, controlling acid-bass loudness; adding a duplicate LEVEL control would be misleading.
- **Waveforms:** SAW, SQUARE and SINE. SINE is a smoother, more sub-bass-like sound; the acid filter will be less dramatic than with SAW or SQUARE.
- **Hold-to-play keys:** on the SYNTH tab, press and hold a note to sustain it; use another finger to sweep CUTOFF, RESO, ENV MOD, DISTORTION, TONE, LEVEL, etc. Release the key to release the voice. The live performance voice does not edit your sequencer or interrupt its bassline. This uses Pointer Events with touch capture, so it is particularly suited to Android multitouch.
- **Bass gate length per step:** SHORT gives a staccato hit, NORMAL is standard and LONG holds approximately into the next step. TIE and SLIDE are still independent choices; off steps remain rests. Select a bass step and press SHORT, NORMAL or LONG beside Accent/Slide/Tie. Existing pitch selection already lets every step have a distinct note, so a second pitch-mode UI is unnecessary.
- **Compatibility:** existing v1.0–v1.2 project JSON and autosaved patterns are normalized automatically; old bass steps default to NORMAL gate length, TONE defaults to neutral, and previous saw/square choices are preserved. Saving a JSON backup before deploying updates is recommended.
- **Offline audio:** four-bar WAV rendering uses the same voice and sequencer modules, including all three waveforms, Tone and gate-length changes. Live key performance itself is not recorded in this version.
- **Known limitations:** The audio engine uses Web Audio synthesis nodes instead of analog-circuit emulation. Testing in desktop Chromium is not a substitute for verifying multi-finger gestures and audio latency on your specific Samsung device. The LONG gate is an approximate note-length option, not a fully independent per-step rhythmic clock (every step still advances on the 16th-note grid).

### Updating the existing GitHub Pages deployment

1. Upload `ACID-08-v1.3.1-PWA-Source.zip` to the root of your existing `ACID-08` GitHub repository.
2. Edit `.github/workflows/deploy.yml` in GitHub and change only its ZIP filename to `ACID-08-v1.3.1-PWA-Source.zip`. Keep the existing `_unpacked/ACID-08/` copy command.
3. Commit the workflow edit and check the Actions tab for a green checkmark.
4. Open your existing GitHub Pages app and refresh. On mobile a second refresh or closing/reopening the PWA may be necessary to switch cached assets after the new service worker activates.

## v1.3.1 — Bass step-note audition fix

- Touching a Bass piano key now assigns the note **and** plays an immediate 340ms preview.
- Uses pointerdown for reliable mobile gestures (replacing on-click handling that could be lost when keys are re-rendered).
- Preview is routed through a separate audio voice, so it does not interrupt live sequencer playback.
- Keyboard accessibility is preserved for Enter and Space.
- Increments the offline service-worker cache version to fetch the updated code.


## v1.3.2: Performance mutes + focused sequencing

- Two quick-mute buttons are shown above the instrument on every tab: BASS ON and DRUMS ON.
- Tap once to mute; the button turns red and says MUTED. Tap again to restore audio.
- The quick buttons stay synchronized with the existing Mixer mute controls.
- Muting fades each bus quickly and affects live playback, keyboard audition, and WAV renders when saved as part of the project.
- Bass tab is bass-specific: no drum grid/overview below the piano keyboard.
- Drums tab shows the six drum sequencer lanes, pads, and track selector.
- Timing engine is unchanged: imported 303/TB-3 style transcriptions can differ due to gate lengths, slides, swing, and source pattern notation. Try zero swing and revise individual gate/slide settings before altering clock timing.
- Existing projects and JSON exports remain compatible. The service worker cache version was advanced for updates.


## v1.3.3 — Independent acid filter modulation

- **Fixed knob/envelope conflict:** In v1.3.2 every UI knob refresh called `setParams()` and scheduled a new cutoff value. That could override the active per-note filter sweep. The revised engine updates only changed sound parameters.
- **Isolated mixer controls:** Unchanged drum levels, mute gains, master level and effect sends are no longer needlessly rescheduled during synth knob drags.
- **True independent filter controls:** A smooth base cutoff and an audio-rate note envelope are now separate signals summed at the filter frequency. Sweeping a knob no longer cancels or resets the step envelope.
- **Expressive accents:** Each accented note gets a stronger filter-envelope peak; decay remains controlled by DECAY. Cutoff, resonance and envelope modulation can be adjusted live.
- **Unchanged project format:** Existing projects, all 16 pattern slots, mutes, drums, WAV export and sound design knobs are retained. There are no new controls to learn.
- **Audio parity:** Both live playback and offline WAV rendering use the same revised filter engine. This is still an original Web Audio approximation, not an exact TB-303 hardware circuit model.
- **Service worker:** Updated cache version to v1.3.3. Reopen or reload the PWA after deployment; export any important patterns to JSON before updates.

### GitHub Pages update

Upload `ACID-08-v1.3.3-PWA-Source.zip` to the existing repository, then replace the ZIP filename in `.github/workflows/deploy.yml` with this file's name. Don't change the existing `_unpacked/ACID-08` path. Commit and confirm Actions shows a green check.


## v1.3.4 — Audible sine-wave sound design

- **SINE harmonic character:** A soft, sine-only analog-style excitation path is blended in before the resonant filter. A pure sine contains only one frequency, so cutoff, resonance, and a high-frequency tone shelf previously had almost nothing audible to shape. SINE now retains its smooth fundamental while presenting modest upper harmonics that the controls can act upon. For an absolutely pure mathematical sine, use a separate oscillator source; ACID-08's SINE is intentionally warm rather than perfectly pure.
- **SINE tone range:** The TONE shelf moves from 1550 Hz to 260 Hz in SINE mode to affect its newly generated harmonics, then returns to the original setting for SAW and SQUARE.
- **No changes to SAW/SQUARE:** Their synthesis routing, cutoff envelope, and characteristic sound are preserved.
- **Performance controls:** LEVEL, CUTOFF, RESO, ENV MOD, TONE, DISTORTION respond as usual. PITCH takes effect on each newly triggered note; DECAY affects the next note envelope; ACCENT and SLIDE are performance/step features rather than continuous effects on an already sustained note.
- **Packaging:** Visible build label, PWA cache, and this README all updated to v1.3.4. JSON project format unchanged. WAV export shares the same voice and includes the sine harmonics.

Deploy: upload `ACID-08-v1.3.4-PWA-Source.zip`, then change `1.3.3` to `1.3.4` in `.github/workflows/deploy.yml`.


## v1.3.5 — Pattern-only imports without changing the sound

- **Fixed the reported sound change on JSON imports.** Older imports loaded the file's `synth`, `mixer`, `tempo`, and `swing` values as well as the pattern steps. This could completely change your sound, even if you only wanted a new bassline.
- Under **⋮ → PROJECT / SYSTEM**, choose **IMPORT PATTERNS ONLY · KEEP MY SOUND** for pattern packs (recommended). The entire 16-slot pattern bank, including bass and drums, is replaced, but your current instrument knobs, effects, master levels, tempo, swing and project name are preserved. The selected pattern slot follows the imported file.
- Choose **IMPORT FULL PROJECT · CHANGE SOUND** when you explicitly want the file's synth preset and all project settings.
- Both import choices make a dated backup of the active project automatically, available under **LOAD**, before replacing the current session. Named projects are not overwritten.
- Original project JSON format unchanged. Previously generated Da Funk / AcidVoice JSON files continue to import correctly.
- Visible build is V1.3.5; offline cache is acid-08-v1.3.5. No synth or sequencer DSP has been modified by this fix.

Deployment: Upload `ACID-08-v1.3.5-PWA-Source.zip` to the existing GitHub repository, then change just `1.3.4` to `1.3.5` in `.github/workflows/deploy.yml`. Confirm deployment succeeds, then reopen/refresh the PWA.


## v1.3.6 — Keyboard recovery, emergency SILENCE, midnight orange

- Fixed a real keyboard-audio bug: STOP previously latched the master output gain at zero. New deliberate audio gestures (Bass note assignment, Synth keyboard, drum audition, TEST and PLAY) now safely re-arm the output. Existing step sequencing and sound DSP are unchanged.
- Synth keyboard holds a note while pressed and releases it on pointer release; short taps that finish during the initial audio unlock still get a brief audible note. Bass keyboard continues to assign and preview a selected step.
- Added a distinct **SILENCE** emergency button beside STOP. SILENCE halts the transport and mutes the entire master output immediately, including delay/reverb tails. A subsequent key, TEST, pad or PLAY intentionally resumes audio.
- Darkened housing and panels and adopted exact accent color **#FF4F00** for the active UI. Labels, keyboard, status, and selected steps remain high contrast.
- New visible release label **V1.3.6**; offline cache **acid-08-v1.3.6**. Pattern-only import, project autosave, all 16 patterns, and exported JSON compatibility remain unchanged.
- **Deployment:** Upload `ACID-08-v1.3.6-PWA-Source.zip` to GitHub, then change only `1.3.5` to `1.3.6` in `.github/workflows/deploy.yml`. Reload ACID-08 after a green deployment check. If an installed PWA still shows an old build, close and reopen it and refresh the site once.
- Browser APIs and Android multitouch behavior should be verified on the target phone. Audio requires a user gesture to initialize.

## v1.3.9 — 16/32 patterns, corrected note articulation

- Each pattern saves its own **16 or 32 step** length. Tap **LENGTH 16 / 32** above the grid; a 16-step pattern loops after step 16 and page 2 is disabled. Going back to 32 reveals the original data on steps 17–32 without deleting it. Newly created blank patterns default to 16 steps. Older project files without saved pattern lengths are treated as 32 steps for compatibility.
- SHORT, NORMAL, LONG are 30%, 69%, 96% note gates within a step. **LONG no longer overlaps subsequent notes by itself**.
- SLIDE on an active step connects that step's pitch to the **next** active step with an audible portamento and legato articulation. SLIDE has no pitch target when the following step is a rest. At a loop boundary, the last step can slide into the first step. TIE can extend into a following rest or connect notes without glide.
- Switching patterns resets the current sequencer voice and transport position so stale sounding notes do not bleed into another pattern or mask live-key audition. The synth controls, keyboard and SILENCE button remain functional and sound presets are not altered by pattern length.
- WAV export renders four bars regardless of the selected pattern's length (16-step loops four times; 32-step loops twice).
- The original #FF4F00-on-charcoal color scheme and Patterns Only / Full Project JSON import are unchanged.

### Regression checklist

1. Import a previous JSON and verify notes, sound and page 2 are retained; older projects without `length` use 32.
2. Select 16. Press Play: the playhead must return to step 1 after step 16. The page-2 button must disable. Switch back to 32 and confirm notes 17–32 are intact.
3. For a short 2-note riff, program 01=C3 and 02=G3: LONG on 01 produces a sustained C3 but not a glide. SLIDE on 01 creates a continuous C3→G3 pitch sweep. Ensure 02 is active.
4. Switch between patterns, play notes on Bass and Synth keyboards, use STOP then SILENCE, then play a key again. No held-note bleed or stuck output.
5. Test live playback and four-bar WAV for both lengths, including an end-to-start slide.

## v1.3.9 — Audio-engine articulation review

- Fixed a legato/slide bug that canceled the remaining filter-envelope decay without replacing it.
- Fixed gate-envelope scheduling so Short/Normal/Long note releases cannot extend past their intended note end.
- Reduced the permanently mixed sub-oscillator beneath Saw/Square so their original harmonic profiles come through; kept fuller bass support for Sine.
- Unchanged: oscillator waveform types, cutoff and resonance mapping, distortion circuit, mixer, drums, existing projects, and 16/32 sequencing.
- Aural judgment is subjective: compare your familiar saved patterns with v1.3.7 before permanently switching. Export a JSON backup first.


## v1.3.9 — Drum balance and tap-to-toggle drum grid

- Drum voices are rebalanced: softer kick, stronger snare, clap and hats, and
  less master-compressor pumping so hits remain audible beneath the bass.
- A gentle peak guard prevents the louder transients from clipping the output.
- On the Drums tab, click/tap an overview cell to turn that specific drum hit
  on or off. The selected drum lane and step update for probability editing.
- The separate 16-step drum editor also retains its existing tap-to-toggle behavior.
- Bass overview cells still select notes for editing; they do not toggle them.
- Existing projects, per-voice volume sliders, and JSON imports stay compatible.
- No changes to the bass oscillator, filter, accent, slide, or distortion code.

As with every sound update, judge the balance on your own speakers/headphones.
These changes affect live playback and offline WAV rendering equally.
