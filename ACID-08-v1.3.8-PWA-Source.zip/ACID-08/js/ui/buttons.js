export function setOn(id,isOn){const node=document.getElementById(id);if(node){node.classList.toggle('on',Boolean(isOn));node.setAttribute('aria-pressed',String(Boolean(isOn)));}}
