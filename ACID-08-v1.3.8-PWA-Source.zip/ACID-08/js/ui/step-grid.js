import {LABELS} from '../core/defaults.js';
export const noteName=(n)=>['C','C♯','D','D♯','E','F','F♯','G','G♯','A','A♯','B'][n%12]+(Math.floor(n/12)-1);
export function renderStepGrid(root,pattern,track,page,selected){const steps=pattern.tracks[track],start=page*16;
  root.innerHTML=Array.from({length:16},(_,i)=>{const j=start+i,s=steps[j];const flags=track==='bass'?[s.accent?'A':'',s.slide?'↗':'',s.tie?'—':'',s.gate==='short'?'S':s.gate==='long'?'L':''].filter(Boolean).join(' '):(s.probability<100?s.probability+'%':'');
    return `<button type="button" class="step ${s.on?'on':''} ${j===selected?'selected':''} ${s.accent?'accent':''} ${s.slide?'slide':''}" data-step="${j}" aria-pressed="${s.on}" title="Step ${j+1}${track==='bass'?' / '+noteName(s.note):''}"><span class="step-index">${String(j+1).padStart(2,'0')}</span><strong>${track==='bass'?(s.on?noteName(s.note):'·'):(s.on?'●':'·')}</strong><small>${flags||' '}</small></button>`;
  }).join('');
  const ruler=document.querySelector('#step-ruler');ruler.innerHTML=Array.from({length:16},(_,i)=>`<span class="${i%4===0?'beat':''}">${i%4===0?'▴':'·'}</span>`).join('');
}
export function updatePlayhead(root,step){for(const node of root.querySelectorAll('[data-step]'))node.classList.toggle('playing',Number(node.dataset.step)===step);}
export function renderTrackSelectors(root,track){root.innerHTML=Object.entries(LABELS).map(([k,v])=>`<button type="button" data-track="${k}" class="${k===track?'active':''}" title="Edit ${v}">${v}</button>`).join('');}

export function renderOverview(root,pattern,page,track,selected){
  const start=page*16;
  root.innerHTML=Object.entries(LABELS).map(([id,label])=>`<div class="overview-lane"><button class="overview-track ${id===track?'selected':''}" data-overview-track="${id}">${label}</button><div class="overview-cells">${Array.from({length:16},(_,i)=>{
    const j=start+i,s=pattern.tracks[id][j];return `<button type="button" class="overview-cell ${s.on?'on':''} ${s.accent?'accent':''} ${id===track&&j===selected?'selected':''}" data-overview-step="${j}" data-overview-id="${id}" title="${label} • step ${j+1}${id==='bass'?' • '+noteName(s.note):''}" aria-label="Edit ${label} step ${j+1} ${s.on?'on':'off'}"></button>`;
  }).join('')}</div></div>`).join('');
}
export function updateOverviewPlayhead(root,step){for(const node of root.querySelectorAll('[data-overview-step]'))node.classList.toggle('playing',Number(node.dataset.overviewStep)===step);}
