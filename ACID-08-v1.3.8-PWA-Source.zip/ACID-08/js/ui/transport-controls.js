export function showTransport(playing){document.getElementById('play').classList.toggle('playing',playing);document.getElementById('stop').classList.toggle('stopped',!playing);}
