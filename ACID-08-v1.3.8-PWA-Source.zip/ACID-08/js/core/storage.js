const DB='acid08-v1',STORE='projects';
export class Storage {
  constructor(){this.db=null;this.fallback=false;}
  async initialize(){
    if(!('indexedDB' in window)){this.fallback=true;return;}
    try {this.db=await new Promise((resolve,reject)=>{
      const req=indexedDB.open(DB,1);
      req.onupgradeneeded=()=>{if(!req.result.objectStoreNames.contains(STORE))req.result.createObjectStore(STORE);};
      req.onsuccess=()=>resolve(req.result);req.onerror=()=>reject(req.error);
      req.onblocked=()=>reject(new Error('Database upgrade blocked'));
    });}catch{this.fallback=true;}
  }
  async get(key){if(this.fallback){try{return JSON.parse(localStorage.getItem('acid08:'+key)||'null');}catch{return null;}}
    return new Promise((resolve,reject)=>{const tx=this.db.transaction(STORE,'readonly');const req=tx.objectStore(STORE).get(key);req.onsuccess=()=>resolve(req.result??null);req.onerror=()=>reject(req.error);});}
  async set(key,value){if(this.fallback){localStorage.setItem('acid08:'+key,JSON.stringify(value));return;}
    return new Promise((resolve,reject)=>{const tx=this.db.transaction(STORE,'readwrite');tx.objectStore(STORE).put(value,key);tx.oncomplete=()=>resolve();tx.onerror=()=>reject(tx.error);});}
  async keys(){if(this.fallback)return Object.keys(localStorage).filter(k=>k.startsWith('acid08:project:')).map(k=>k.slice(7));
    return new Promise((resolve,reject)=>{const tx=this.db.transaction(STORE,'readonly');const req=tx.objectStore(STORE).getAllKeys();req.onsuccess=()=>resolve(req.result.filter(k=>k.startsWith('project:')));req.onerror=()=>reject(req.error);});}
}
