import {AcidVoice} from '../synth/acid-voice.js';
import {DrumEngine} from '../drums/drum-engine.js';
import {Effects} from '../synth/effects.js';
export class AudioEngine {
  constructor(ctx,project){
    this.ctx=ctx;this.project=project;this.lastMixer=null;
    this.bassBus=ctx.createGain();this.drumBus=ctx.createGain();this.bassBus.gain.value=1;this.drumBus.gain.value=1;
    this.mix=ctx.createGain();this.mix.gain.value=0.77;
    this.effects=new Effects(ctx,this.mix,project.mixer);
    this.bassBus.connect(this.mix);this.drumBus.connect(this.mix);
    this.bassBus.connect(this.effects.delayInput);this.drumBus.connect(this.effects.delayInput);
    this.bassBus.connect(this.effects.reverbInput);this.drumBus.connect(this.effects.reverbInput);
    this.voice=new AcidVoice(ctx,this.bassBus,project.synth);
    // Independent performance voice: live keyboard never interrupts the programmed bassline.
    this.performanceVoice=new AcidVoice(ctx,this.bassBus,project.synth);
    this.drums=new DrumEngine(ctx,this.drumBus,project.mixer.drumLevels);
    this.compressor=ctx.createDynamicsCompressor();this.compressor.threshold.value=-7;this.compressor.knee.value=6;this.compressor.ratio.value=6;this.compressor.attack.value=0.004;this.compressor.release.value=0.13;
    this.output=ctx.createGain();this.output.gain.value=1;
    this.mix.connect(this.compressor);this.compressor.connect(this.output);this.output.connect(ctx.destination);
    this.updateProject(project);
  }
  updateProject(project){
    this.project=project;
    this.voice.setParams(project.synth);
    this.performanceVoice.setParams(project.synth);
    const m=project.mixer,old=this.lastMixer,t=this.ctx.currentTime;
    // Knob changes must not restart mixer/envelope automation elsewhere.
    if(!old||Object.keys(m.drumLevels).some(k=>old.drumLevels[k]!==m.drumLevels[k])){
      this.drums.setLevels(m.drumLevels);
    }
    if(!old||['delay','reverb','delayFeedback'].some(k=>old[k]!==m[k])){
      this.effects.set(m);
    }
    if(!old||old.bassMute!==m.bassMute)this.bassBus.gain.setTargetAtTime(m.bassMute?0:1,t,0.015);
    if(!old||old.drumMute!==m.drumMute)this.drumBus.gain.setTargetAtTime(m.drumMute?0:1,t,0.015);
    if(!old||old.master!==m.master)this.mix.gain.setTargetAtTime(0.2+(m.master*0.6),t,0.012);
    this.lastMixer={...m,drumLevels:{...m.drumLevels}};
  }
  scheduleStep(pattern,index,time,duration,stepNumber=0){
    const length=pattern.length===16?16:32;
    const b=pattern.tracks.bass;
    const step=b[index];
    const prev=b[(index+length-1)%length],next=b[(index+1)%length];
    if(step.on){
      // Gates end within their step unless explicitly tied. A long gate is
      // sustained articulation, not a slide or a note stealing the next step.
      const gateRatio=step.gate==='short'?0.30:step.gate==='long'?0.96:0.69;
      const nextDuration=60/this.project.tempo/4*(1+(stepNumber%2===0?-this.project.swing:this.project.swing));
      const continuation=Boolean(next.on&&(step.slide||step.tie));
      const extraTie=Boolean(step.tie&&!next.on);
      const gateDuration=duration*gateRatio+(extraTie?nextDuration*0.92:0);
      const legato=Boolean(stepNumber>0&&prev.on&&(prev.slide||prev.tie));
      this.voice.trigger(step.note,time,gateDuration,{
        accent:step.accent,legato,hold:continuation,stepLength:duration,
        slideFromPrevious:Boolean(stepNumber>0&&prev.on&&prev.slide)
      });
    }
    for(const name of ['kick','snare','clap','tom','closedHat','openHat']){
      const s=pattern.tracks[name][index];
      if(s.on&&this.passProbability(s.probability,stepNumber,name))this.drums.trigger(name,time);
    }
  }
  passProbability(prob,stepNumber,name){
    if(prob>=100)return true;if(prob<=0)return false;
    // Deterministic hash: offline render matches live decisions for corresponding pass.
    let id=0;for(let i=0;i<name.length;i++)id=Math.imul(id+name.charCodeAt(i),31)>>>0;let h=((stepNumber+1)*2654435761+id)>>>0;h=Math.imul(h^(h>>>16),2246822519)>>>0;
    return h%100<prob;
  }
  click(time,strong=false){const ctx=this.ctx,osc=ctx.createOscillator(),g=ctx.createGain();osc.type='sine';osc.frequency.value=strong?1150:850;
    g.gain.setValueAtTime(0.11,time);g.gain.exponentialRampToValueAtTime(0.0001,time+0.048);osc.connect(g);g.connect(this.mix);osc.start(time);osc.stop(time+0.06);
  }
  noteOn(note){const t=this.ctx.currentTime+0.008;this.performanceVoice.trigger(note,t,0.35,{accent:false,hold:true});}
  noteOff(){this.performanceVoice.release();}
  testTone(){const t=this.ctx.currentTime+0.01;this.performanceVoice.silence(t);this.performanceVoice.trigger(36,t,0.33,{accent:true});}
  panic(){const t=this.ctx.currentTime;this.voice.silence(t);this.performanceVoice.silence(t);this.output.gain.cancelScheduledValues(t);this.output.gain.setValueAtTime(0,t);}
  unpanic(){this.output.gain.cancelScheduledValues(this.ctx.currentTime);this.output.gain.setTargetAtTime(1,this.ctx.currentTime,0.006);}
  dispose(){this.panic();this.voice.dispose();this.performanceVoice.dispose();}
}
export async function initializeLiveAudio(project){
  const AudioContextClass=window.AudioContext||window.webkitAudioContext;
  if(!AudioContextClass)throw new Error('This browser does not support Web Audio API.');
  let ctx;
  try{ctx=new AudioContextClass({latencyHint:'interactive'});await ctx.resume();if(ctx.state!=='running')throw new Error(`Audio context state is ${ctx.state}`);return {ctx,engine:new AudioEngine(ctx,project)};}
  catch(error){if(ctx)await ctx.close().catch(()=>{});throw new Error(`Audio initialization failed: ${error.message}`);}
}
