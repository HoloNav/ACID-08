import {normalizeProject} from './defaults.js';
export function makeJSON(project){return JSON.stringify({...project,updatedAt:new Date().toISOString()},null,2);}
export function parseJSON(contents){return normalizeProject(JSON.parse(contents));}
// Importing a pattern bank must never overwrite sound-design or transport controls.
export function mergePatternsOnly(current,incoming){
  return {
    ...current,
    patterns:structuredClone(incoming.patterns),
    selectedPattern:incoming.selectedPattern,
    updatedAt:new Date().toISOString()
  };
}
export function downloadBlob(contents,name,mime){const blob=contents instanceof Blob?contents:new Blob([contents],{type:mime});const url=URL.createObjectURL(blob);const a=document.createElement('a');a.href=url;a.download=name;document.body.append(a);a.click();a.remove();setTimeout(()=>URL.revokeObjectURL(url),3000);}
export function safeFilename(s){return String(s).replace(/[^a-z0-9_\-]+/gi,'-').replace(/^-|-$/g,'').slice(0,60)||'acid08';}
