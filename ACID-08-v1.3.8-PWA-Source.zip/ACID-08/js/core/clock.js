export function stepDuration(bpm,swing,index){const base=60/bpm/4;return base*(index%2===0?1+swing:1-swing);}
