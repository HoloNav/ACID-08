export function tapTempo(taps,now=performance.now()){
  const recent=taps.filter(t=>now-t<2300);recent.push(now);
  if(recent.length>5)recent.shift();
  if(recent.length<2)return {taps:recent,bpm:null};
  const intervals=recent.slice(1).map((v,i)=>v-recent[i]).filter(n=>n>200&&n<1100);
  if(!intervals.length)return {taps:recent,bpm:null};
  const bpm=Math.round(60000/(intervals.reduce((a,b)=>a+b,0)/intervals.length));
  return {taps:recent,bpm:Math.max(60,Math.min(240,bpm))};
}
