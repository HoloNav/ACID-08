export function setPattern(project,index){project.selectedPattern=Math.max(0,Math.min(15,Math.trunc(index)));}
export function currentPattern(project){return project.patterns[project.selectedPattern];}
