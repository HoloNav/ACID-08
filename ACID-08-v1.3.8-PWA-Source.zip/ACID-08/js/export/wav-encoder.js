export function encodeWAV(buffer,frames=buffer.length){
  const channels=2,bytes=frames*channels*2,result=new ArrayBuffer(44+bytes),view=new DataView(result);
  const str=(offset,text)=>{for(let i=0;i<text.length;i++)view.setUint8(offset+i,text.charCodeAt(i));};
  str(0,'RIFF');view.setUint32(4,36+bytes,true);str(8,'WAVE');str(12,'fmt ');view.setUint32(16,16,true);
  view.setUint16(20,1,true);view.setUint16(22,2,true);view.setUint32(24,buffer.sampleRate,true);
  view.setUint32(28,buffer.sampleRate*channels*2,true);view.setUint16(32,channels*2,true);view.setUint16(34,16,true);str(36,'data');view.setUint32(40,bytes,true);
  const left=buffer.getChannelData(0),right=buffer.numberOfChannels>1?buffer.getChannelData(1):left;
  for(let i=0,at=44;i<frames;i++){for(const sample of [left[i],right[i]]){const x=Math.max(-1,Math.min(1,sample));view.setInt16(at,x<0?Math.round(x*32768):Math.round(x*32767),true);at+=2;}}
  return new Blob([result],{type:'audio/wav'});
}
