import {createProject,normalizeProject} from './core/defaults.js';
import {initializeLiveAudio} from './core/audio-engine.js';
import {Sequencer} from './core/sequencer.js';import {Storage} from './core/storage.js';
import {tapTempo} from './core/transport.js';import {currentPattern,setPattern} from './core/pattern-manager.js';
import {makeJSON,parseJSON,mergePatternsOnly,downloadBlob,safeFilename} from './core/project-manager.js';
import {renderFourBars} from './export/wav-renderer.js';
import {knobMarkup,bindKnobs,refreshKnobs} from './ui/knobs.js';
import {renderStepGrid,renderTrackSelectors,updatePlayhead,renderOverview,updateOverviewPlayhead,noteName} from './ui/step-grid.js';
import {renderPatterns} from './ui/pattern-selector.js';import {renderDrumPads} from './ui/mixer.js';
import {setOn} from './ui/buttons.js';import {showTransport} from './ui/transport-controls.js';
import {displayStatus,showAudioStatus} from './ui/display.js';
const $=(id)=>document.getElementById(id),clamp=(n,a,b)=>Math.max(a,Math.min(b,n));
class ACIDApp {
  constructor(){this.project=createProject();this.engine=null;this.ctx=null;this.storage=new Storage();this.track='bass';this.lastDrumTrack='kick';this.view='bass';this.page=0;this.selectedStep=0;this.octave=2;this.saveTimer=null;this.tapTimes=[];this.busy=false;this.importMode='patterns';this.audioEpoch=0;
    this.sequencer=new Sequencer(()=>this.project,()=>this.engine,(step)=>this.playhead(step));}
  async initialize(){
    this.renderAll();this.bindEvents();this.setView('bass');
    try{await this.storage.initialize();const saved=await this.storage.get('draft');if(saved){this.project=normalizeProject(saved);this.renderAll();displayStatus('RESTORED YOUR LAST AUTO-SAVED SESSION.');}
      $('storage-state').textContent=this.storage.fallback?'SAVE: LOCAL FALLBACK':'SAVE: INDEXEDDB READY';
    }catch(e){$('storage-state').textContent='SAVE: UNAVAILABLE';displayStatus('STORAGE ERROR: '+e.message,true);}
    if('serviceWorker' in navigator&&location.protocol!=='file:')navigator.serviceWorker.register('./service-worker.js').catch(()=>{});
    document.addEventListener('visibilitychange',()=>{if(document.hidden&&this.sequencer.playing){this.sequencer.stop();showTransport(false);displayStatus('PLAYBACK PAUSED WHEN APP MOVED TO BACKGROUND.');}});
    window.addEventListener('pagehide',()=>{clearTimeout(this.saveTimer);this.saveDraft();});
  }
  async ensureAudio(){
    if(this.engine){if(this.ctx.state==='suspended')await this.ctx.resume();if(this.ctx.state!=='running')throw Error('AudioContext did not resume; tap POWER again.');return;}
    showAudioStatus('AUDIO ENGINE STARTING...',false);
    try{const result=await initializeLiveAudio(this.project);this.ctx=result.ctx;this.engine=result.engine;showAudioStatus(`ENGINE READY / ${this.ctx.sampleRate} HZ / ${this.ctx.baseLatency?Math.round(this.ctx.baseLatency*1000)+' MS BASE LATENCY':'LOW-LATENCY MODE'}`,true);}
    catch(e){showAudioStatus('ENGINE ERROR: '+e.message,false);displayStatus(e.message,true);throw e;}
  }
  change(){this.project.updatedAt=new Date().toISOString();clearTimeout(this.saveTimer);this.saveTimer=setTimeout(()=>this.saveDraft(),550);this.engine?.updateProject(this.project);}
  async saveDraft(){try{await this.storage.set('draft',this.project);$('storage-state').textContent=this.storage.fallback?'SAVE: LOCAL FALLBACK':'SAVE: AUTO-SAVED';}catch(e){$('storage-state').textContent='SAVE FAILED';displayStatus('AUTO-SAVE FAILED: '+e.message,true);}}
  renderAll(){this.renderSynth();this.renderSequencer();this.renderDrums();this.renderMixer();this.renderTransport();this.setView(this.view);}
  setView(view){
    if(!['bass','drums','synth','mix'].includes(view))return;
    if(view!==this.view){if(this.heldKey){this.engine?.noteOff();this.heldKey=null;}this.heldToken++;}
    this.view=view;
    if(view==='bass')this.track='bass';
    if(view==='drums')this.track=this.lastDrumTrack;
    document.querySelector('.device').dataset.view=view;
    for(const tab of document.querySelectorAll('[data-view-tab]')){
      const active=tab.dataset.viewTab===view;
      tab.classList.toggle('active',active);
      tab.setAttribute('aria-selected',String(active));
    }
    if(view==='bass'||view==='drums'){
      document.querySelector('.sequencer-panel h2').textContent=view==='bass'?'BASS STEP EDITOR':'DRUM STEP EDITOR';
      document.querySelector('.step-top .micro-label').textContent=view==='bass'?'TAP A STEP → TAP A PIANO KEY':'SELECT A DRUM → TAP STEPS TO TOGGLE';
      this.renderSequencer();
    }
  }

  renderSynth(){const root=$('synth-knobs');if(!root.dataset.bound){root.innerHTML=knobMarkup(this.project.synth);bindKnobs(root,(key,value)=>{this.project.synth[key]=value;this.change();});root.dataset.bound='true';}else refreshKnobs(root,this.project.synth);
    document.querySelectorAll('[data-wave]').forEach(el=>el.classList.toggle('active',el.dataset.wave===this.project.synth.wave));document.querySelectorAll('[data-filter]').forEach(el=>el.classList.toggle('active',el.dataset.filter===this.project.synth.filterMode));}
  renderSequencer(){
    const length=currentPattern(this.project).length===16?16:32;
    if(length===16){this.page=0;if(this.selectedStep>=16)this.selectedStep=0;}
    for(const btn of document.querySelectorAll('[data-pattern-length]')){
      const active=Number(btn.dataset.patternLength)===length;
      btn.classList.toggle('active',active);btn.setAttribute('aria-pressed',String(active));
    }
    $('page-2').disabled=length===16;
    $('page-2').title=length===16?'Switch to 32 steps to edit page 2':'Edit steps 17–32';
    $('length-readout').textContent=length+' STEPS';
    renderPatterns($('pattern-slots'),this.project.selectedPattern);$('pattern-info').textContent='A'+String(this.project.selectedPattern+1).padStart(2,'0');
    renderTrackSelectors($('track-selectors'),this.track);$('page-1').classList.toggle('active',this.page===0);$('page-2').classList.toggle('active',this.page===1);
    this.renderSteps();}
  renderSteps(){renderStepGrid($('step-grid'),currentPattern(this.project),this.track,this.page,this.selectedStep);this.renderEditor();renderOverview($('overview'),currentPattern(this.project),this.page,this.track,this.selectedStep);this.playhead(this.sequencer.current);}
  renderEditor(){const s=currentPattern(this.project).tracks[this.track][this.selectedStep],isBass=this.track==='bass';
    $('selected-step-title').textContent=`${this.track==='bass'?'BASS':this.track.replace(/([A-Z])/g,' $1').toUpperCase()} / STEP ${String(this.selectedStep+1).padStart(2,'0')}`;
    $('step-note-readout').textContent=isBass?noteName(s.note):'TRIGGER '+(s.on?'ON':'OFF');
    setOn('step-on',s.on);for(const flag of ['accent','slide','tie']){ $(flag).hidden=!isBass;setOn(flag,isBass&&s[flag]);}
    $('prob-label').hidden=isBass;$('probability').value=isBass?100:s.probability;$('prob-value').textContent=isBass?'':s.probability+'%';
    $('gate-edit').hidden=!isBass;document.querySelectorAll('[data-gate]').forEach(btn=>{const active=isBass&&s.gate===btn.dataset.gate;btn.classList.toggle('active',active);btn.setAttribute('aria-pressed',String(active));});
    $('keyboard-section').hidden=!isBass;document.querySelector('#keyboard-section .keyboard-caption > span').textContent=`STEP ${String(this.selectedStep+1).padStart(2,'0')} — TAP A NOTE TO ASSIGN`;this.renderKeyboard();}
  renderKeyboard(){
    const s=currentPattern(this.project).tracks.bass[this.selectedStep];
    $('octave-display').textContent='OCT '+this.octave;
    $('synth-octave-display').textContent='OCT '+this.octave;
    const isBlack=i=>[1,3,6,8,10].includes(i%12);
    const makeKeys=(forSynth)=>{
      const white=[],black=[];
      for(let i=0;i<=24;i++){
        const n=12*(this.octave+1)+i;
        const chosen=!forSynth&&s.note===n?'chosen':'';
        const title=`${forSynth?'Audition':'Assign'} ${noteName(n)}`;
        const label=forSynth?`Audition ${noteName(n)}`:`Assign ${noteName(n)} to step ${this.selectedStep+1}`;
        if(isBlack(i)){
          const before=Array.from({length:i},(_,j)=>j).filter(j=>!isBlack(j)).length;
          black.push(`<button type="button" data-note="${n}" aria-label="${label}" title="${title}" class="key black ${chosen}" style="left:calc(${(before/15*100).toFixed(4)}% - 2.45%)"><span>${noteName(n)}</span></button>`);
        }else{
          white.push(`<button type="button" data-note="${n}" aria-label="${label}" title="${title}" class="key white ${chosen}"><span>${noteName(n)}</span></button>`);
        }
      }
      return white.join('')+black.join('');
    };
    $('keyboard').innerHTML=makeKeys(false);
    $('synth-keyboard').innerHTML=makeKeys(true);
  }
  renderDrums(){renderDrumPads($('drum-pads'),this.project.mixer.drumLevels);}
  renderMixer(){const p=this.project; $('bpm').value=p.tempo;$('master-level').value=p.mixer.master;$('master-val').textContent=Math.round(p.mixer.master*100)+'%';
    $('delay-send').value=p.mixer.delay;$('delay-val').textContent=Math.round(p.mixer.delay*100)+'%';$('reverb-send').value=p.mixer.reverb;$('reverb-val').textContent=Math.round(p.mixer.reverb*100)+'%';
    $('swing').value=Math.round(p.swing*100);$('swing-val').textContent=Math.round(p.swing*100)+'%';
    this.renderMutes();setOn('metronome',p.mixer.metronome);$('project-name').textContent=p.name;}
  renderMutes(){
    const m=this.project.mixer;
    for(const [id,quick,muted,onLabel,offLabel] of [['bass-mute','quick-bass-mute',m.bassMute,'BASS MUTED','BASS ON'],['drum-mute','quick-drum-mute',m.drumMute,'DRUMS MUTED','DRUMS ON']]){
      setOn(id,muted);setOn(quick,muted);
      $(quick).textContent=muted?onLabel:offLabel;
      $(quick).setAttribute('aria-label',(muted?'Unmute ':'Mute ')+(quick==='quick-bass-mute'?'bass track':'drum tracks'));
      $(quick).title=muted?'Tap to hear this track again':'Tap to silence this track';
    }
  }
  renderTransport(){showTransport(this.sequencer.playing);}
  playhead(step){updatePlayhead($('step-grid'),step);updateOverviewPlayhead($('overview'),step);$('position-readout').textContent=step>=0?`${String(Math.floor(step/16)+1).padStart(2,'0')} : ${String(step%16+1).padStart(2,'0')}`:'-- : --';}
  async sound(action){
    const epoch=this.audioEpoch;
    try{
      await this.ensureAudio();
      // A pending keyboard/pad gesture must not undo an emergency SILENCE.
      if(epoch!==this.audioEpoch)return;
      // STOP and SILENCE deliberately mute the entire output. A fresh gesture
      // (keyboard, pad, TEST, or PLAY) must restore it before sounding a note.
      this.engine.unpanic();
      $('silence').classList.remove('engaged');
      action();
    }catch(e){console.error(e);}
  }
  silenceEverything(){
    this.audioEpoch++;
    // The latched output gain stops drums, live keys, scheduled notes and FX tails.
    // Pressing a key or PLAY later explicitly re-arms the master output.
    this.heldToken++;
    if(this.heldKey){
      this.heldKey.key.classList.remove('held');
      this.heldKey.key.setAttribute('aria-pressed','false');
      this.heldKey=null;
    }
    this.sequencer.stop();
    this.engine?.panic();
    this.renderTransport();
    displayStatus('SILENCE — ALL AUDIO CUT. TAP A KEY OR PLAY TO RESUME.');
    const button=$('silence');button.classList.add('engaged');
  }
  bindEvents(){
    document.querySelector('.workstation-tabs').addEventListener('click',e=>{
      const tab=e.target.closest('[data-view-tab]');if(tab)this.setView(tab.dataset.viewTab);
    });
    $('power').addEventListener('click',()=>this.sound(()=>{this.engine.testTone();displayStatus('AUDIO ENABLED. TEST TONE PLAYED.');}));
    $('test-tone').addEventListener('click',()=>this.sound(()=>this.engine.testTone()));
    $('play').addEventListener('click',()=>this.sound(()=>{this.sequencer.start();this.renderTransport();displayStatus('TRANSPORT RUNNING — AUDIO-CLOCK SCHEDULING.');}));
    $('stop').addEventListener('click',()=>{this.sequencer.stop();this.renderTransport();displayStatus('TRANSPORT STOPPED — TAP A KEY TO AUDITION.');});
    $('silence').addEventListener('click',()=>this.silenceEverything());
    $('bpm-minus').addEventListener('click',()=>this.setBpm(this.project.tempo-1));$('bpm-plus').addEventListener('click',()=>this.setBpm(this.project.tempo+1));
    $('bpm').addEventListener('change',e=>this.setBpm(Number(e.target.value)));
    $('tap-tempo').addEventListener('click',()=>{const r=tapTempo(this.tapTimes);this.tapTimes=r.taps;if(r.bpm)this.setBpm(r.bpm);});
    for(const btn of document.querySelectorAll('[data-wave]'))btn.addEventListener('click',()=>{this.project.synth.wave=btn.dataset.wave;this.change();this.renderSynth();});
    for(const btn of document.querySelectorAll('[data-filter]'))btn.addEventListener('click',()=>{this.project.synth.filterMode=btn.dataset.filter;this.change();this.renderSynth();});
    $('pattern-slots').addEventListener('click',e=>{
      const b=e.target.closest('[data-pattern]');if(!b)return;
      const index=Number(b.dataset.pattern);if(index===this.project.selectedPattern)return;
      // Re-arm the transport from step 1. This prevents a previously held
      // slide/tie from bleeding into a different pattern or masking live keys.
      const wasPlaying=this.sequencer.playing;
      if(wasPlaying)this.sequencer.stop();
      else this.engine?.voice.silence();
      setPattern(this.project,index);this.page=0;this.selectedStep=0;
      this.renderSequencer();this.change();
      if(wasPlaying)this.sound(()=>{this.sequencer.start();this.renderTransport();});
      displayStatus(`PATTERN A${String(this.project.selectedPattern+1).padStart(2,'0')} SELECTED — PROGRAMMING PRESERVED.`);
    });
    $('track-selectors').addEventListener('click',e=>{const b=e.target.closest('[data-track]');if(!b)return;this.track=b.dataset.track;if(this.track!=='bass')this.lastDrumTrack=this.track;this.renderSequencer();});
    $('page-1').addEventListener('click',()=>this.setPage(0));$('page-2').addEventListener('click',()=>this.setPage(1));
    document.querySelector('.pattern-length').addEventListener('click',e=>{
      const button=e.target.closest('[data-pattern-length]');if(!button)return;
      const length=Number(button.dataset.patternLength);
      const pattern=currentPattern(this.project);
      if(pattern.length===length)return;
      pattern.length=length;
      // Notes on the hidden page survive the change back to 32 steps.
      // Restart the transport at a measure boundary and clear any hanging voice.
      const wasPlaying=this.sequencer.playing;
      if(wasPlaying)this.sequencer.stop();
      this.page=0;this.selectedStep=0;
      this.change();this.renderSequencer();this.renderTransport();
      if(wasPlaying)this.sound(()=>{this.sequencer.start();this.renderTransport();});
      displayStatus(`${length}-STEP PATTERN — ${length===16?'ONE BAR LOOP':'TWO BAR LOOP'}. HIDDEN STEPS PRESERVED.`);
    });
    $('step-grid').addEventListener('click',e=>{const b=e.target.closest('[data-step]');if(!b)return;this.selectedStep=Number(b.dataset.step);
      if(this.track!=='bass'){const s=currentPattern(this.project).tracks[this.track][this.selectedStep];s.on=!s.on;this.change();}
      this.renderSteps();});
    $('overview').addEventListener('click',e=>{const b=e.target.closest('[data-overview-step]');if(!b){const t=e.target.closest('[data-overview-track]');if(t){this.track=t.dataset.overviewTrack;if(this.track!=='bass')this.lastDrumTrack=this.track;this.setView(this.track==='bass'?'bass':'drums');}return;}
      this.track=b.dataset.overviewId;this.selectedStep=Number(b.dataset.overviewStep);if(this.track!=='bass')this.lastDrumTrack=this.track;this.setView(this.track==='bass'?'bass':'drums');});
    $('step-on').addEventListener('click',()=>this.toggleStep());
    for(const flag of ['accent','slide','tie'])$(flag).addEventListener('click',()=>{if(this.track!=='bass')return;const s=currentPattern(this.project).tracks.bass[this.selectedStep];s[flag]=!s[flag];if(s[flag])s.on=true;this.change();this.renderSteps();});
    $('gate-edit').addEventListener('click',e=>{const btn=e.target.closest('[data-gate]');if(!btn||this.track!=='bass')return;const step=currentPattern(this.project).tracks.bass[this.selectedStep];step.gate=btn.dataset.gate;step.on=true;this.change();this.renderSteps();});
    $('probability').addEventListener('input',e=>{if(this.track==='bass')return;const s=currentPattern(this.project).tracks[this.track][this.selectedStep];s.probability=Number(e.target.value);$('prob-value').textContent=s.probability+'%';this.change();});
    // Bass keyboard is both a step programmer and a musical audition keyboard.
    // Handle pointerdown rather than click: renderSteps replaces the key elements,
    // which can suppress the eventual click on mobile browsers.
    const programBassKey=(key)=>{
      if(!key||this.track!=='bass')return;
      const note=Number(key.dataset.note);
      const step=currentPattern(this.project).tracks.bass[this.selectedStep];
      step.note=note;step.on=true;
      const accent=step.accent;
      this.change();this.renderSteps();
      // Audition on the independent performance voice. Never disrupt the step sequencer.
      this.sound(()=>this.engine.performanceVoice.trigger(note,this.ctx.currentTime+0.006,0.34,{accent}));
    };
    $('keyboard').addEventListener('pointerdown',e=>{
      const key=e.target.closest('[data-note]');if(!key)return;
      e.preventDefault();programBassKey(key);
    });
    // Enter / Space activation for accessibility does not generate pointerdown.
    $('keyboard').addEventListener('click',e=>{
      if(e.detail!==0)return;
      programBassKey(e.target.closest('[data-note]'));
    });
    // Press-and-hold on the Synth keyboard: live sustain plus true two-finger knob control.
    // The performance voice is separate from the sequencer voice and never edits patterns.
    this.heldKey=null;this.heldToken=0;
    const synthKeyboard=$('synth-keyboard');
    synthKeyboard.addEventListener('pointerdown',e=>{
      const key=e.target.closest('[data-note]');if(!key||this.heldKey)return;
      e.preventDefault();const token=++this.heldToken,note=Number(key.dataset.note);
      const state={pointerId:e.pointerId,note,key,token,hasStarted:false,released:false};
      this.heldKey=state;
      key.classList.add('held');key.setAttribute('aria-pressed','true');
      try{key.setPointerCapture(e.pointerId);}catch{}
      // If a first touch needs to initialize/resume audio, even a short tap
      // is audible. If still held when ready, sustain until pointer release.
      this.sound(()=>{
        if(this.heldToken!==token)return; // SILENCE, blur or tab change cancelled it
        if(state.released){
          this.engine.performanceVoice.trigger(note,this.ctx.currentTime+0.008,0.22);
        }else if(this.heldKey===state){
          this.engine.noteOn(note);state.hasStarted=true;
        }
      });
    });
    const releaseHeld=e=>{
      if(!this.heldKey||this.heldKey.pointerId!==e.pointerId)return;
      const state=this.heldKey;
      state.key.classList.remove('held');state.key.setAttribute('aria-pressed','false');
      state.released=true;
      this.heldKey=null;
      // Don't invalidate token before a slow first-touch audio unlock has
      // a chance to make a brief note. Normal held notes release now.
      if(state.hasStarted){this.heldToken++;this.engine?.noteOff();}
    };
    synthKeyboard.addEventListener('pointerup',releaseHeld);
    synthKeyboard.addEventListener('pointercancel',releaseHeld);
    synthKeyboard.addEventListener('lostpointercapture',releaseHeld);
    window.addEventListener('blur',()=>{if(!this.heldKey)return;this.heldKey.key.classList.remove('held');this.heldKey=null;this.heldToken++;this.engine?.noteOff();});
    // Desktop keyboard activation supports a brief audible preview.
    synthKeyboard.addEventListener('click',e=>{if(e.detail!==0)return;const key=e.target.closest('[data-note]');if(!key)return;
      this.sound(()=>{this.engine.performanceVoice.trigger(Number(key.dataset.note),this.ctx.currentTime+0.01,0.25);});
    });
    for(const [id,delta] of [['octave-down',-1],['octave-up',1],['synth-octave-down',-1],['synth-octave-up',1]]){
      $(id).addEventListener('click',()=>{this.octave=clamp(this.octave+delta,1,5);if(this.heldKey){this.engine?.noteOff();this.heldKey=null;this.heldToken++;}this.renderKeyboard();});
    }
    $('drum-pads').addEventListener('click',e=>{const b=e.target.closest('[data-audition]');if(!b)return;const pad=b.closest('.drum-pad');pad.classList.add('hit');setTimeout(()=>pad.classList.remove('hit'),150);
      this.sound(()=>this.engine.drums.trigger(b.dataset.audition,this.ctx.currentTime+0.01));});
    $('drum-pads').addEventListener('input',e=>{const input=e.target.closest('[data-drum-level]');if(!input)return;this.project.mixer.drumLevels[input.dataset.drumLevel]=Number(input.value);$('drum-pads').querySelector(`[data-drum-value="${input.dataset.drumLevel}"]`).textContent=Math.round(Number(input.value)*100)+'%';this.change();});
    for(const [id,key,out] of [['master-level','master','master-val'],['delay-send','delay','delay-val'],['reverb-send','reverb','reverb-val']])$(id).addEventListener('input',e=>{this.project.mixer[key]=Number(e.target.value);$(out).textContent=Math.round(e.target.value*100)+'%';this.change();});
    $('swing').addEventListener('input',e=>{this.project.swing=Number(e.target.value)/100;$('swing-val').textContent=e.target.value+'%';this.change();});
    for(const [id,key] of [['bass-mute','bassMute'],['drum-mute','drumMute'],['quick-bass-mute','bassMute'],['quick-drum-mute','drumMute'],['metronome','metronome']])$(id).addEventListener('click',()=>{
      this.project.mixer[key]=!this.project.mixer[key];
      if(key==='metronome')setOn(id,this.project.mixer[key]);else this.renderMutes();
      this.change();
    });
    $('save-project').addEventListener('click',()=>this.saveNamed());$('load-project').addEventListener('click',()=>this.openLibrary());
    $('more').addEventListener('click',()=>this.openMenu());$('export-wav').addEventListener('click',()=>this.exportWAV());
    $('modal-close').addEventListener('click',()=>this.closeModal());$('modal').addEventListener('click',e=>{if(e.target===$('modal'))this.closeModal();});
    $('json-file').addEventListener('change',e=>this.importJSON(e.target.files?.[0]));
    document.addEventListener('keydown',e=>{if(e.key==='Escape')this.closeModal();if(e.code==='Space'&&!['BUTTON','INPUT','TEXTAREA'].includes(document.activeElement?.tagName)){
      e.preventDefault();if(this.sequencer.playing){this.sequencer.stop();this.renderTransport();}else this.sound(()=>{this.sequencer.start();this.renderTransport();});}});
  }
  setBpm(v){this.project.tempo=clamp(Math.round(v)||126,60,240);$('bpm').value=this.project.tempo;this.change();}
  setPage(n){if(n===1&&currentPattern(this.project).length!==32)return;this.page=n;this.selectedStep=n*16;this.renderSequencer();}
  toggleStep(){const s=currentPattern(this.project).tracks[this.track][this.selectedStep];s.on=!s.on;this.change();this.renderSteps();}
  openModal(title,html){$('modal-title').textContent=title;$('modal-body').innerHTML=html;$('modal').hidden=false;}
  closeModal(){$('modal').hidden=true;}
  async saveNamed(){const name=prompt('Name this project (save to device):',this.project.name);if(name===null)return;const clean=name.trim().slice(0,80);if(!clean){displayStatus('PROJECT NAME CANNOT BE EMPTY.',true);return;}
    try{const exists=await this.storage.get('project:'+clean);if(exists&&!confirm(`A saved project named "${clean}" already exists. Overwrite it?`))return;
      this.project.name=clean;await this.storage.set('project:'+clean,this.project);await this.saveDraft();this.renderMixer();displayStatus(`SAVED "${clean}" TO THIS DEVICE.`);
    }catch(e){displayStatus('SAVE FAILED: '+e.message,true);}}
  async openLibrary(){try{const keys=await this.storage.keys();this.openModal('SAVED PROJECTS',keys.length?
    `<p class="modal-help">Choose a named project to load. Your current session is auto-saved separately.</p>${keys.map(k=>`<button class="library-item" data-library="${encodeURIComponent(k)}">${this.escapeHTML(k.slice(8))}</button>`).join('')}`:
    '<p>No named projects yet. Use SAVE to add one. Your current work is auto-saved.</p>');
    $('modal-body').querySelectorAll('[data-library]').forEach(b=>b.addEventListener('click',async()=>{try{const next=await this.storage.get(decodeURIComponent(b.dataset.library));if(!next)throw Error('Project not found');this.sequencer.stop();this.project=normalizeProject(next);this.engine?.updateProject(this.project);this.closeModal();this.renderAll();this.change();displayStatus(`LOADED "${this.project.name}".`);}catch(e){displayStatus('LOAD FAILED: '+e.message,true);}}));
    }catch(e){displayStatus('LIBRARY FAILED: '+e.message,true);}}
  openMenu(){this.openModal('PROJECT / SYSTEM',`<p class="modal-help">Choose how you want to import a JSON file. <strong>Patterns Only</strong> keeps your current synth sound, mixer, tempo and swing. Full Project replaces everything. Both options replace all 16 pattern slots.</p><div class="modal-actions"><button id="json-export" class="control-button">↓ EXPORT PROJECT JSON</button><button id="json-import-patterns" class="control-button">↑ IMPORT PATTERNS ONLY · KEEP MY SOUND</button><button id="json-import-full" class="control-button">↑ IMPORT FULL PROJECT · CHANGE SOUND</button><button id="reset-demo" class="control-button">RESET TO DEMO</button></div><p class="modal-help">Before every import, a dated backup of your current session is saved under LOAD. PWA installation: open from HTTPS or localhost in Android Chrome. WAV exports four bars plus an effects tail.</p>`);
    $('json-export').addEventListener('click',()=>{downloadBlob(makeJSON(this.project),safeFilename(this.project.name)+'.json','application/json');this.closeModal();});
    for(const [id,mode] of [['json-import-patterns','patterns'],['json-import-full','full']]){
      $(id).addEventListener('click',()=>{this.importMode=mode;$('json-file').value='';$('json-file').click();this.closeModal();});
    }
    $('reset-demo').addEventListener('click',()=>{if(!confirm('Reset your current session to the demo? Saved named projects will remain intact.'))return;this.sequencer.stop();this.project=createProject();this.engine?.updateProject(this.project);this.renderAll();this.change();this.closeModal();});
  }
  async importJSON(file){
    if(!file)return;
    try{
      if(file.size>2_000_000)throw Error('File larger than 2MB');
      const next=parseJSON(await file.text());
      const patternsOnly=this.importMode!=='full';
      const message=patternsOnly
        ? `Import all 16 patterns from "${next.name}"? This REPLACES your current pattern bank but KEEPS your sound, mixer, tempo, and swing. A backup will be saved under LOAD.`
        : `Import full project "${next.name}"? This REPLACES patterns, sound settings, mixer, tempo, and swing. A backup will be saved under LOAD.`;
      if(!confirm(message))return;
      // Save the unmodified session first, so an imported pack can never silently erase it.
      const backupName=`Before Import ${new Date().toISOString()}`;
      await this.storage.set(`project:${backupName}`,structuredClone(this.project));
      this.sequencer.stop();
      this.project=patternsOnly?mergePatternsOnly(this.project,next):next;
      this.engine?.updateProject(this.project);
      this.renderAll();this.change();
      displayStatus(patternsOnly
        ? `IMPORTED 16 PATTERNS FROM "${next.name}" — CURRENT SOUND / TEMPO PRESERVED.`
        : `IMPORTED FULL PROJECT "${next.name}" — SOUND SETTINGS LOADED.`);
    }catch(e){displayStatus('IMPORT FAILED: '+e.message,true);}
  }
  async exportWAV(){if(this.busy)return;this.busy=true;const b=$('export-wav'),old=b.textContent;b.textContent='RENDERING…';b.disabled=true;
    try{displayStatus('RENDERING FOUR BARS OFFLINE AT 44.1 KHZ / 16 BIT / STEREO...');const blob=await renderFourBars(structuredClone(this.project));
      downloadBlob(blob,`${safeFilename(this.project.name)}-pattern-${String(this.project.selectedPattern+1).padStart(2,'0')}.wav`,'audio/wav');displayStatus(`WAV READY — ${(blob.size/1024/1024).toFixed(1)} MB / FOUR BARS + 2S TAIL.`);
    }catch(e){displayStatus('WAV EXPORT FAILED: '+e.message,true);console.error(e);}finally{b.textContent=old;b.disabled=false;this.busy=false;}}
  escapeHTML(str){return str.replace(/[&<>"']/g,c=>({'&':'&amp;','<':'&lt;','>':'&gt;','"':'&quot;',"'":'&#039;'}[c]));}
}
new ACIDApp().initialize();
