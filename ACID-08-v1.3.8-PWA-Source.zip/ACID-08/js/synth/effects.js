function impulse(ctx){
  const secs=1.75,len=Math.floor(ctx.sampleRate*secs),b=ctx.createBuffer(2,len,ctx.sampleRate);let seed=981234;
  for(let c=0;c<2;c++){const d=b.getChannelData(c);for(let i=0;i<len;i++){seed=(Math.imul(seed,1664525)+1013904223)>>>0;d[i]=((seed/2147483648)-1)*Math.pow(1-i/len,2.4)*0.46;}}
  return b;
}
export class Effects {
  constructor(ctx,destination,settings){
    this.ctx=ctx;this.delayInput=ctx.createGain();this.reverbInput=ctx.createGain();
    const l=ctx.createDelay(1.5),r=ctx.createDelay(1.5),fbl=ctx.createGain(),fbr=ctx.createGain();
    l.delayTime.value=0.285;r.delayTime.value=0.425;this.delayInput.connect(l);this.delayInput.connect(r);
    l.connect(fbl);fbl.connect(r);r.connect(fbr);fbr.connect(l);
    const merger=ctx.createChannelMerger(2);l.connect(merger,0,0);r.connect(merger,0,1);
    this.delayWet=ctx.createGain();merger.connect(this.delayWet);this.delayWet.connect(destination);
    this.fbl=fbl;this.fbr=fbr;
    const convolver=ctx.createConvolver();convolver.buffer=impulse(ctx);
    this.reverbWet=ctx.createGain();this.reverbInput.connect(convolver);convolver.connect(this.reverbWet);this.reverbWet.connect(destination);
    this.set(settings);
  }
  set(p){const t=this.ctx.currentTime;this.delayWet.gain.setTargetAtTime((p.delay??0.1)*0.42,t,0.017);this.reverbWet.gain.setTargetAtTime((p.reverb??0.1)*0.45,t,0.017);for(const g of [this.fbl,this.fbr])g.gain.setTargetAtTime(Math.min(0.69,p.delayFeedback??0.31),t,0.017);}
}
