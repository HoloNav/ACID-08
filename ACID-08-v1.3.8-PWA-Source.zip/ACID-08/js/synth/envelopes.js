export function cancelAndSet(param,value,time){param.cancelScheduledValues(time);param.setValueAtTime(value,time);}
export function releaseEnvelope(param,time,duration=0.024){param.cancelScheduledValues(time);param.setTargetAtTime(0,time,duration/4);param.setValueAtTime(0,time+duration*6);}
