export const clamp=(n,min,max)=>Math.min(max,Math.max(min,n));
export function cutoffToHz(value){return 65*Math.pow(115,clamp(value,0,1));}
export function resonanceToQ(value){return 0.7+Math.pow(clamp(value,0,1),2.15)*22;}
