import {midiToHz,createVCO} from './oscillator.js';
import {cutoffToHz,resonanceToQ,clamp} from './filter.js';

function driveCurve(amount=11){
  const arr=new Float32Array(1024);
  for(let i=0;i<arr.length;i++){
    const x=2*i/(arr.length-1)-1;
    arr[i]=Math.tanh(amount*x)/Math.tanh(amount);
  }
  return arr;
}

/**
 * Acid bass voice: independent filter base-cutoff and note-envelope modulation.
 *
 * Directly writing filter.frequency on EVERY UI change used to overwrite the
 * programmed note envelope (and some browsers canceled pending automation).
 * Now two audio-rate control signals sum at filter.frequency:
 *   cutoffSource.offset + envelopeShape * envelopeDepth
 * Only controls that actually changed are updated. Bass steps retain their
 * envelopes while LEVEL, TONE, DRIVE, etc. are manipulated mid-pattern.
 * All nodes work in regular and OfflineAudioContext for matching WAV export.
 */
export class AcidVoice {
  constructor(ctx,destination,params){
    this.ctx=ctx;
    this.params={...params};
    this.initialized=false;
    this.lastNote=36;
    this.held=false;
    this.vco=createVCO(ctx,'sawtooth');
    this.sub=createVCO(ctx,'sine');
    // A permanent -1 octave sub made Saw and Square unnaturally rounded.
    // Keep their natural harmonics forward, with a subtler low-end foundation.
    this.subGain=ctx.createGain();this.subGain.gain.value=0.075;
    this.pre=ctx.createGain();this.pre.gain.value=0.55;
    // A mathematically pure sine has no overtones for a resonant LPF or Tone
    // shelf to shape. Add a gentle, sine-only nonlinear parallel voice BEFORE
    // the filter. The original fundamental stays clear and Saw/Square are unchanged.
    // This also behaves identically in Web Audio and OfflineAudioContext.
    this.sineDry=ctx.createGain();this.sineDry.gain.value=1;
    this.sineExciterInput=ctx.createGain();this.sineExciterInput.gain.value=2.1;
    this.sineExciter=ctx.createWaveShaper();this.sineExciter.curve=driveCurve(4.2);this.sineExciter.oversample='2x';
    this.sineExciterMix=ctx.createGain();this.sineExciterMix.gain.value=0;
    this.filter=ctx.createBiquadFilter();this.filter.type='lowpass';

    // Filter frequency: independent live base and per-note envelope.
    // The filter's intrinsic frequency is zero, so AudioParam connections sum.
    this.filter.frequency.value=0;
    this.cutoffSource=ctx.createConstantSource();
    this.cutoffSource.offset.value=cutoffToHz(this.params.cutoff);
    this.cutoffSource.connect(this.filter.frequency);
    this.envelopeSource=ctx.createConstantSource();
    this.envelopeSource.offset.value=1;
    this.envelopeShape=ctx.createGain();this.envelopeShape.gain.value=0;
    this.envelopeDepth=ctx.createGain();this.envelopeDepth.gain.value=0;
    this.envelopeSource.connect(this.envelopeShape);
    this.envelopeShape.connect(this.envelopeDepth);
    this.envelopeDepth.connect(this.filter.frequency);

    this.cleanGain=ctx.createGain();
    this.driveInput=ctx.createGain();
    this.saturator=ctx.createWaveShaper();this.saturator.curve=driveCurve(3.3);this.saturator.oversample='2x';
    this.crunchGain=ctx.createGain();
    this.tone=ctx.createBiquadFilter();this.tone.type='highshelf';this.tone.frequency.value=1550;
    this.gate=ctx.createGain();this.gate.gain.value=0;
    this.output=ctx.createGain();this.output.gain.value=0.8;

    this.vco.connect(this.sineDry);this.sineDry.connect(this.pre);
    this.vco.connect(this.sineExciterInput);this.sineExciterInput.connect(this.sineExciter);
    this.sineExciter.connect(this.sineExciterMix);this.sineExciterMix.connect(this.pre);
    this.sub.connect(this.subGain);this.subGain.connect(this.pre);
    this.pre.connect(this.filter);
    this.filter.connect(this.cleanGain);this.cleanGain.connect(this.tone);
    this.filter.connect(this.driveInput);this.driveInput.connect(this.saturator);
    this.saturator.connect(this.crunchGain);this.crunchGain.connect(this.tone);
    this.tone.connect(this.gate);this.gate.connect(this.output);this.output.connect(destination);

    this.setParams(params);
    this.cutoffSource.start();this.envelopeSource.start();
    this.vco.start();this.sub.start();
  }

  // The filter envelope remains open and expressive, even after the user
  // releases a control. Respect the effective maximum of the Web Audio filter.
  envelopeHz(p){
    const base=cutoffToHz(p.cutoff);
    return clamp(base * (Number(p.envMod)||0) * 10.2,0,Math.max(0,14500-base));
  }

  setParams(p){
    const prev=this.params;
    const next={...prev,...p};
    const first=!this.initialized;
    const changed=(key)=>first||prev[key]!==next[key];
    this.params=next;
    const t=this.ctx.currentTime;

    if(changed('wave')){
      const sine=next.wave==='sine';
      this.vco.type=next.wave==='square'?'square':sine?'sine':'sawtooth';
      // Preserve the fundamental, blend in odd harmonics for audible filter sweeps.
      this.sineDry.gain.setTargetAtTime(sine?0.95:1,t,0.008);
      this.sineExciterMix.gain.setTargetAtTime(sine?0.26:0,t,0.008);
      this.subGain.gain.setTargetAtTime(sine?0.15:0.075,t,0.012);
      // Pure sine is low-frequency heavy; move the tone shelf toward the actual
      // overtone range while in sine mode. Existing waveforms retain 1550 Hz.
      this.tone.frequency.setTargetAtTime(sine?260:1550,t,0.016);
    }
    if(changed('filterMode'))this.filter.type=next.filterMode==='bandpass'?'bandpass':'lowpass';
    if(changed('resonance'))this.filter.Q.setTargetAtTime(resonanceToQ(next.resonance),t,0.015);

    // Live cutoff sweeps move the base only; the step envelope continues to run.
    if(changed('cutoff'))this.cutoffSource.offset.setTargetAtTime(cutoffToHz(next.cutoff),t,0.014);
    if(changed('cutoff')||changed('envMod')){
      this.envelopeDepth.gain.setTargetAtTime(this.envelopeHz(next),t,0.02);
    }

    if(changed('tone'))this.tone.gain.setTargetAtTime((next.tone-0.5)*22,t,0.015);
    if(changed('level'))this.output.gain.setTargetAtTime(0.2+next.level*0.7,t,0.01);
    if(changed('distortion')){
      const drive=clamp(Number(next.distortion)||0,0,1);
      this.driveInput.gain.setTargetAtTime(0.85+drive*6.3,t,0.012);
      this.cleanGain.gain.setTargetAtTime(1-0.91*drive,t,0.012);
      this.crunchGain.gain.setTargetAtTime(0.55*drive,t,0.012);
    }
    this.initialized=true;
  }

  trigger(note,time,stepDuration,{accent=false,legato=false,hold=false,stepLength=stepDuration,slideFromPrevious=false}={}){
    const p=this.params,t=Math.max(time,this.ctx.currentTime);
    const freq=midiToHz(note+Math.round(p.pitch));
    const glide=clamp(stepLength*(0.22+p.slide*0.52),0.025,Math.max(0.03,stepLength*0.9));
    this.gate.gain.cancelScheduledValues(t);
    // IMPORTANT: do NOT cancel the existing filter decay for an unaccented
    // legato note. That used to freeze the filter envelope mid-slide and make
    // the same Saw/Square patch sound very different from note to note.
    if(!legato || accent)this.envelopeShape.gain.cancelScheduledValues(t);
    for(const osc of [this.vco,this.sub]){
      const f=osc.frequency,ratio=osc===this.sub?0.5:1;
      f.cancelScheduledValues(t);
      if(legato){
        f.setValueAtTime(midiToHz(this.lastNote+Math.round(p.pitch))*ratio,t);
        if(slideFromPrevious&&Math.abs(this.lastNote-note)>0)f.exponentialRampToValueAtTime(freq*ratio,t+glide);
        else f.setValueAtTime(freq*ratio,t);
      } else f.setValueAtTime(freq*ratio,t);
    }
    // Exponential filter envelope independent of knob updates. A short, sharp
    // accented peak adds the familiar per-note squelch without a stuck cutoff.
    const filterDecay=0.035+Math.pow(p.decay,1.4)*0.63;
    const shape=this.envelopeShape.gain;
    const accentBoost=accent?1.0+p.accent*0.85:1.0;
    // A connected slide/tie keeps the previous envelope alive; unlike a new
    // note it does not re-strike the filter. Accents may re-emphasize it.
    if(!legato||accent){
      shape.setValueAtTime(accentBoost,t);
      shape.exponentialRampToValueAtTime(0.0001,t+Math.max(0.03,filterDecay*2.1));
    }

    const g=this.gate.gain;
    const level=accent?Math.min(1.3,0.85+p.accent*0.38):0.74;
    if(!legato){g.setValueAtTime(0.0001,t);g.linearRampToValueAtTime(level,t+0.004);}
    else {g.setValueAtTime(level*0.9,t);g.linearRampToValueAtTime(level,t+0.012);}
    // The amplitude shape must finish within the requested gate. Previously
    // the decay and release endpoints could run PAST a short note's gate,
    // briefly re-opening it and softening the distinction between articulations.
    const gateLength=Math.max(0.018,stepDuration);
    const releaseTime=Math.min(0.018,Math.max(0.005,gateLength*0.22));
    const end=t+gateLength;
    const attackEnd=t+(legato?0.012:0.004);
    const decayEnd=Math.max(attackEnd+0.002,Math.min(t+Math.max(0.014,filterDecay*0.55),end-releaseTime-0.002));
    // The melodic envelope is per-note; do not let its decay automation spill
    // into the release, or a subsequent step, at high tempos.
    if(decayEnd>attackEnd)g.exponentialRampToValueAtTime(Math.max(0.2,level*0.67),decayEnd);
    if(!hold){
      const relStart=Math.max(decayEnd+0.001,end-releaseTime);
      g.setValueAtTime(Math.max(0.2,level*0.67),relStart);
      g.exponentialRampToValueAtTime(0.0001,end);
    }
    this.lastNote=note;
    this.held=Boolean(hold);
  }

  release(time=this.ctx.currentTime){
    const t=Math.max(this.ctx.currentTime,time),g=this.gate.gain;
    g.cancelScheduledValues(t);
    g.setTargetAtTime(0.0001,t,0.018);
    g.setValueAtTime(0,t+0.15);
    this.held=false;
  }

  silence(time=this.ctx.currentTime){
    const t=Math.max(this.ctx.currentTime,time);
    this.held=false;
    this.gate.gain.cancelScheduledValues(t);this.gate.gain.setValueAtTime(0,t);
    this.envelopeShape.gain.cancelScheduledValues(t);this.envelopeShape.gain.setValueAtTime(0,t);
    this.vco.frequency.cancelScheduledValues(t);this.sub.frequency.cancelScheduledValues(t);
  }

  dispose(){
    for(const node of [this.vco,this.sub,this.cutoffSource,this.envelopeSource]){
      try{node.stop();}catch{}
      try{node.disconnect();}catch{}
    }
    for(const node of [this.sineDry,this.sineExciterInput,this.sineExciter,this.sineExciterMix,this.envelopeShape,this.envelopeDepth,this.output]){
      try{node.disconnect();}catch{}
    }
  }
}
