export const midiToHz = (note)=>440*Math.pow(2,(note-69)/12);
export function createVCO(ctx,type='sawtooth') {
  const oscillator=ctx.createOscillator();oscillator.type=type;return oscillator;
}
