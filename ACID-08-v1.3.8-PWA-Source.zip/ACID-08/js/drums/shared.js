export function noiseSource(ctx,buffer){const source=ctx.createBufferSource();source.buffer=buffer;return source;}
export function outputEnv(ctx,dest,time,level,decay){const env=ctx.createGain();env.gain.setValueAtTime(Math.max(0.0001,level),time);env.gain.exponentialRampToValueAtTime(0.0001,time+decay);env.connect(dest);return env;}
export function makeNoiseBuffer(ctx,seconds=1){
  const b=ctx.createBuffer(1,Math.ceil(ctx.sampleRate*seconds),ctx.sampleRate);const d=b.getChannelData(0);let seed=22334455;
  for(let i=0;i<d.length;i++){seed=(Math.imul(1664525,seed)+1013904223)>>>0;d[i]=(seed/2147483648)-1;}
  return b;
}
