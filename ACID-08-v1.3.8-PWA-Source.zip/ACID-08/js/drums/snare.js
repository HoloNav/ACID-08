import {noiseSource,outputEnv} from './shared.js';
export function snare(ctx,dest,noise,time,vel=1){
  const src=noiseSource(ctx,noise),filter=ctx.createBiquadFilter();filter.type='bandpass';filter.frequency.value=1800;filter.Q.value=0.65;
  const env=outputEnv(ctx,dest,time,0.58*vel,0.22);src.connect(filter);filter.connect(env);src.start(time);src.stop(time+0.27);
  const tone=ctx.createOscillator();tone.type='triangle';tone.frequency.setValueAtTime(190,time);tone.frequency.exponentialRampToValueAtTime(115,time+0.09);
  const te=outputEnv(ctx,dest,time,0.38*vel,0.12);tone.connect(te);tone.start(time);tone.stop(time+0.16);
}
