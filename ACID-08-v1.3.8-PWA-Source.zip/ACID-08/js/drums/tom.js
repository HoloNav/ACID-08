import {outputEnv} from './shared.js';
export function tom(ctx,dest,noise,time,vel=1){
  const env=outputEnv(ctx,dest,time,0.7*vel,0.31);
  for(const [type,freq,level] of [['sine',240,1],['triangle',360,0.22]]){
    const osc=ctx.createOscillator(),gain=ctx.createGain();osc.type=type;gain.gain.value=level;
    osc.frequency.setValueAtTime(freq,time);osc.frequency.exponentialRampToValueAtTime(freq*0.55,time+0.18);
    osc.connect(gain);gain.connect(env);osc.start(time);osc.stop(time+0.35);
  }
}
