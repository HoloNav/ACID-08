import {makeNoiseBuffer} from './shared.js';
import {kick} from './kick.js';import {snare} from './snare.js';import {clap} from './clap.js';import {tom} from './tom.js';import {hat} from './hat.js';
export class DrumEngine {
  constructor(ctx,destination,levels){this.ctx=ctx;this.noise=makeNoiseBuffer(ctx);this.levels={};this.nodes={};for(const id of ['kick','snare','clap','tom','closedHat','openHat']){const g=ctx.createGain();g.gain.value=levels[id]??0.7;g.connect(destination);this.nodes[id]=g;}this.openHat=null;}
  setLevels(levels){for(const [id,n] of Object.entries(levels))if(this.nodes[id])this.nodes[id].gain.setTargetAtTime(n,this.ctx.currentTime,0.015);}
  trigger(id,time,velocity=1){const t=Math.max(this.ctx.currentTime,time),dest=this.nodes[id];if(!dest)return;
    if(id==='kick')kick(this.ctx,dest,this.noise,t,velocity);
    if(id==='snare')snare(this.ctx,dest,this.noise,t,velocity);
    if(id==='clap')clap(this.ctx,dest,this.noise,t,velocity);
    if(id==='tom')tom(this.ctx,dest,this.noise,t,velocity);
    if(id==='openHat')this.openHat=hat(this.ctx,dest,this.noise,t,velocity,true);
    if(id==='closedHat'){if(this.openHat)this.openHat.choke(t);hat(this.ctx,dest,this.noise,t,velocity,false);}
  }
}
