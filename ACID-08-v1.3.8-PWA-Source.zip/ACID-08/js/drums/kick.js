import {noiseSource,outputEnv} from './shared.js';
export function kick(ctx,dest,noise,time,vel=1){
  const osc=ctx.createOscillator();osc.type='sine';const env=outputEnv(ctx,dest,time,0.95*vel,0.42);
  osc.frequency.setValueAtTime(164,time);osc.frequency.exponentialRampToValueAtTime(48,time+0.09);osc.frequency.exponentialRampToValueAtTime(42,time+0.35);
  osc.connect(env);osc.start(time);osc.stop(time+0.47);
  const src=noiseSource(ctx,noise),hp=ctx.createBiquadFilter();hp.type='highpass';hp.frequency.value=2400;
  const click=outputEnv(ctx,dest,time,0.14*vel,0.015);src.connect(hp);hp.connect(click);src.start(time);src.stop(time+0.021);
}
