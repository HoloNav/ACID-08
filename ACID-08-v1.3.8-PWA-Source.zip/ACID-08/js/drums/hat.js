import {noiseSource,outputEnv} from './shared.js';
export function hat(ctx,dest,noise,time,vel=1,isOpen=false){
  const decay=isOpen?0.49:0.095;
  const mix=ctx.createGain(),hp=ctx.createBiquadFilter(),bp=ctx.createBiquadFilter();
  hp.type='highpass';hp.frequency.value=isOpen?5800:7000;hp.Q.value=0.7;
  bp.type='bandpass';bp.frequency.value=isOpen?9500:10500;bp.Q.value=0.7;
  const out=outputEnv(ctx,dest,time,(isOpen?0.30:0.39)*vel,decay);
  mix.connect(hp);hp.connect(bp);bp.connect(out);
  const src=noiseSource(ctx,noise);src.connect(mix);src.start(time);src.stop(time+decay+0.01);
  for(const f of [2972,4176,5298]){
    const osc=ctx.createOscillator(),g=ctx.createGain();osc.type='square';osc.frequency.value=f;g.gain.value=0.07;
    osc.connect(g);g.connect(mix);osc.start(time);osc.stop(time+decay+0.01);
  }
  return {choke(t){const x=Math.max(time,t);try{out.gain.cancelScheduledValues(x);out.gain.setValueAtTime(0.1*vel,x);out.gain.exponentialRampToValueAtTime(0.0001,x+0.024);}catch{}}};
}
