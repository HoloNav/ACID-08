import {AudioEngine} from '../core/audio-engine.js';
import {stepDuration} from '../core/clock.js';import {encodeWAV} from './wav-encoder.js';
export async function renderFourBars(project){
  const Offline=window.OfflineAudioContext||window.webkitOfflineAudioContext;
  if(!Offline)throw new Error('OfflineAudioContext is unavailable in this browser.');
  const exactBars=4*4*60/project.tempo;
  const sampleRate=44100,tail=2.0,preroll=0.055;
  const ctx=new Offline(2,Math.ceil((exactBars+tail+preroll)*sampleRate),sampleRate);
  const engine=new AudioEngine(ctx,project);engine.updateProject(project);
  let t=preroll;
  const pattern=project.patterns[project.selectedPattern];
  for(let i=0;i<64;i++){
    const step=i%32,dur=stepDuration(project.tempo,project.swing,i);
    engine.scheduleStep(pattern,step,t,dur,i);
    if(project.mixer.metronome&&step%4===0)engine.click(t,step%16===0);
    t+=dur;
  }
  // The saved file includes a 2s effects tail so delay and reverb are not cut off.
  const rendered=await ctx.startRendering();return encodeWAV(rendered);
}
