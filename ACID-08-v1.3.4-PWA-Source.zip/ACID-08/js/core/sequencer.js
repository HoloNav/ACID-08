import {stepDuration} from './clock.js';
export class Sequencer {
  constructor(getProject,getEngine,onStep){this.getProject=getProject;this.getEngine=getEngine;this.onStep=onStep;this.playing=false;this.nextTime=0;this.absStep=0;this.timer=null;this.queue=[];this.current=-1;this.frame=null;this.lookahead=0.13;}
  start(){if(this.playing)return;const engine=this.getEngine();if(!engine)return;
    this.playing=true;this.absStep=0;this.queue=[];this.current=-1;
    engine.voice.silence();engine.unpanic();this.nextTime=engine.ctx.currentTime+0.08;
    this.tick();this.timer=setInterval(()=>this.tick(),23);this.draw();
  }
  tick(){if(!this.playing)return;const engine=this.getEngine(),ctx=engine.ctx,p=this.getProject();
    while(this.nextTime<ctx.currentTime+this.lookahead&&this.playing){
      const step=this.absStep%32,time=this.nextTime,duration=stepDuration(p.tempo,p.swing,this.absStep);
      const pattern=p.patterns[p.selectedPattern];engine.scheduleStep(pattern,step,time,duration,this.absStep);
      if(p.mixer.metronome&&step%4===0)engine.click(time,step%16===0);
      this.queue.push({step,time});this.nextTime+=duration;this.absStep++;
    }
  }
  draw(){if(!this.playing)return;const ctx=this.getEngine().ctx;
    while(this.queue.length&&this.queue[0].time<=ctx.currentTime+0.009){const ev=this.queue.shift();this.current=ev.step;this.onStep(ev.step);}
    this.frame=requestAnimationFrame(()=>this.draw());
  }
  stop(){this.playing=false;if(this.timer)clearInterval(this.timer);if(this.frame)cancelAnimationFrame(this.frame);this.timer=null;this.frame=null;this.queue=[];this.current=-1;this.getEngine()?.panic();this.onStep(-1);}
}
