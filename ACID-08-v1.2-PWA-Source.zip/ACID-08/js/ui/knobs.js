const DESCRIPTORS=[['level','LEVEL',0,1,0.68],['pitch','PITCH',-12,12,0],['decay','DECAY',0,1,0.46],['cutoff','CUTOFF',0,1,0.38],['resonance','RESO',0,1,0.73],['envMod','ENV MOD',0,1,0.77],['accent','ACCENT',0,1,0.65],['slide','SLIDE',0,1,0.57],['distortion','DISTORTION',0,1,0.0]];
export function knobMarkup(p){return DESCRIPTORS.map(([key,label,min,max])=>{
  const v=p[key],angle=-135+270*((v-min)/(max-min));
  return `<div class="knob-unit"><div class="knob-marks"><div class="knob" tabindex="0" role="slider" aria-label="${label}" aria-valuemin="${min}" aria-valuemax="${max}" aria-valuenow="${v}" data-knob="${key}" style="--angle:${angle}deg"><div class="knob-inset"><div class="knob-pointer"></div></div></div></div><span class="knob-name">${label}</span><span class="knob-value" data-knob-value="${key}">${format(key,v)}</span></div>`;
}).join('');}
export function format(key,value){return key==='pitch'?(value>0?'+':'')+Math.round(value)+' ST':Math.round(value*100)+'%';}
export function bindKnobs(root,onChange){let drag=null;
  function set(key,value){const desc=DESCRIPTORS.find(d=>d[0]===key),min=desc[2],max=desc[3];const v=Math.max(min,Math.min(max,key==='pitch'?Math.round(value):Math.round(value*100)/100));
    const node=root.querySelector(`[data-knob="${key}"]`),label=root.querySelector(`[data-knob-value="${key}"]`);
    node.style.setProperty('--angle',(-135+270*(v-min)/(max-min))+'deg');node.setAttribute('aria-valuenow',String(v));label.textContent=format(key,v);onChange(key,v);
  }
  root.addEventListener('pointerdown',e=>{const el=e.target.closest('[data-knob]');if(!el)return;
    drag={el,id:e.pointerId,y:e.clientY,key:el.dataset.knob,start:Number(el.getAttribute('aria-valuenow'))};el.setPointerCapture(e.pointerId);e.preventDefault();});
  root.addEventListener('pointermove',e=>{if(!drag||e.pointerId!==drag.id)return;const d=DESCRIPTORS.find(x=>x[0]===drag.key);set(drag.key,drag.start+(drag.y-e.clientY)*(d[3]-d[2])/145);});
  root.addEventListener('pointerup',()=>{drag=null;});root.addEventListener('pointercancel',()=>{drag=null;});
  root.addEventListener('wheel',e=>{const el=e.target.closest('[data-knob]');if(!el)return;e.preventDefault();const d=DESCRIPTORS.find(x=>x[0]===el.dataset.knob),step=el.dataset.knob==='pitch'?1:0.02;set(el.dataset.knob,Number(el.getAttribute('aria-valuenow'))+(e.deltaY<0?step:-step));},{passive:false});
  root.addEventListener('keydown',e=>{const el=e.target.closest('[data-knob]');if(!el)return;if(!['ArrowUp','ArrowDown','ArrowLeft','ArrowRight','Home','End'].includes(e.key))return;e.preventDefault();const d=DESCRIPTORS.find(x=>x[0]===el.dataset.knob);const current=Number(el.getAttribute('aria-valuenow')),step=el.dataset.knob==='pitch'?1:0.02;
    set(el.dataset.knob,e.key==='Home'?d[2]:e.key==='End'?d[3]:current+(['ArrowUp','ArrowRight'].includes(e.key)?step:-step));});
}
export function refreshKnobs(root,p){for(const [key,,min,max] of DESCRIPTORS){const v=p[key],el=root.querySelector(`[data-knob="${key}"]`);if(!el)continue;el.setAttribute('aria-valuenow',String(v));el.style.setProperty('--angle',(-135+270*(v-min)/(max-min))+'deg');root.querySelector(`[data-knob-value="${key}"]`).textContent=format(key,v);}}
