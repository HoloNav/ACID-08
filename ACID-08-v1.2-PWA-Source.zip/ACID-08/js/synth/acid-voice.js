import {midiToHz,createVCO} from './oscillator.js';
import {cutoffToHz,resonanceToQ,clamp} from './filter.js';
function driveCurve(amount=11){const arr=new Float32Array(1024);for(let i=0;i<arr.length;i++){const x=2*i/(arr.length-1)-1;arr[i]=Math.tanh(amount*x)/Math.tanh(amount);}return arr;}
export class AcidVoice {
  constructor(ctx,destination,params){
    this.ctx=ctx;this.params={...params};this.lastNote=36;
    this.vco=createVCO(ctx,'sawtooth');this.sub=createVCO(ctx,'sine');
    this.subGain=ctx.createGain();this.subGain.gain.value=0.17;
    this.pre=ctx.createGain();this.pre.gain.value=0.55;
    this.filter=ctx.createBiquadFilter();this.filter.type='lowpass';
    // Parallel clean/crunch paths preserve articulation and allow smooth, click-free drive changes.
    this.cleanGain=ctx.createGain();
    this.driveInput=ctx.createGain();
    this.saturator=ctx.createWaveShaper();this.saturator.curve=driveCurve(3.3);this.saturator.oversample='2x';
    this.crunchGain=ctx.createGain();
    this.gate=ctx.createGain();this.gate.gain.value=0;
    this.output=ctx.createGain();this.output.gain.value=0.8;
    this.vco.connect(this.pre);this.sub.connect(this.subGain);this.subGain.connect(this.pre);
    this.pre.connect(this.filter);
    this.filter.connect(this.cleanGain);this.cleanGain.connect(this.gate);
    this.filter.connect(this.driveInput);this.driveInput.connect(this.saturator);
    this.saturator.connect(this.crunchGain);this.crunchGain.connect(this.gate);
    this.gate.connect(this.output);this.output.connect(destination);
    this.setParams(this.params);this.vco.start();this.sub.start();
  }
  setParams(p){
    this.params={...this.params,...p};const t=this.ctx.currentTime;
    this.vco.type=this.params.wave==='square'?'square':'sawtooth';
    this.filter.type=this.params.filterMode==='bandpass'?'bandpass':'lowpass';
    this.filter.Q.setTargetAtTime(resonanceToQ(this.params.resonance),t,0.015);
    // Do not cancel programmed filter events while a pattern is running.
    this.filter.frequency.setTargetAtTime(cutoffToHz(this.params.cutoff),t,0.018);
    this.output.gain.setTargetAtTime(0.2+this.params.level*0.7,t,0.01);
    const drive=clamp(Number(this.params.distortion)||0,0,1);
    // At 0: unaffected clean bass. At 1: strong clipped harmonics with output compensation.
    this.driveInput.gain.setTargetAtTime(0.85+drive*6.3,t,0.012);
    this.cleanGain.gain.setTargetAtTime(1-0.91*drive,t,0.012);
    this.crunchGain.gain.setTargetAtTime(0.55*drive,t,0.012);
  }
  trigger(note,time,stepDuration,{accent=false,legato=false,hold=false}={}){
    const p=this.params,t=Math.max(time,this.ctx.currentTime),freq=midiToHz(note+Math.round(p.pitch));
    const glide=clamp(stepDuration*(0.12+p.slide*0.77),0.012,0.38);
    this.gate.gain.cancelScheduledValues(t);this.filter.frequency.cancelScheduledValues(t);
    for(const osc of [this.vco,this.sub]) {
      const f=osc.frequency,ratio=osc===this.sub?0.5:1;
      f.cancelScheduledValues(t);
      if(legato){f.setValueAtTime(midiToHz(this.lastNote+Math.round(p.pitch))*ratio,t);f.exponentialRampToValueAtTime(freq*ratio,t+glide);}
      else f.setValueAtTime(freq*ratio,t);
    }
    const envCutoff=cutoffToHz(p.cutoff);
    const envBoost=(accent?1+p.accent*1.45:1)*p.envMod;
    const peak=clamp(envCutoff*(1+envBoost*9.0),80,14000);
    const filterDecay=0.035+Math.pow(p.decay,1.4)*0.63;
    const filter=this.filter.frequency;
    filter.setValueAtTime(Math.max(envCutoff,peak),t);
    filter.exponentialRampToValueAtTime(Math.max(55,envCutoff),t+Math.max(0.03,filterDecay*2.1));
    const g=this.gate.gain,level=accent?Math.min(1.3,0.85+p.accent*0.38):0.74;
    if(!legato){g.setValueAtTime(0.0001,t);g.linearRampToValueAtTime(level,t+0.004);}
    else {g.setValueAtTime(level*0.86,t);g.linearRampToValueAtTime(level,t+0.012);}
    g.exponentialRampToValueAtTime(Math.max(0.2,level*0.67),t+Math.max(0.05,filterDecay));
    if(!hold) {const end=t+Math.max(0.04,stepDuration*0.88);g.setValueAtTime(Math.max(0.2,level*0.67),end);g.exponentialRampToValueAtTime(0.0001,end+0.055);}
    this.lastNote=note;
  }
  silence(time=this.ctx.currentTime){
    const t=Math.max(this.ctx.currentTime,time);this.gate.gain.cancelScheduledValues(t);this.gate.gain.setValueAtTime(0,t);
    this.filter.frequency.cancelScheduledValues(t);this.filter.frequency.setValueAtTime(cutoffToHz(this.params.cutoff),t);
    this.vco.frequency.cancelScheduledValues(t);this.sub.frequency.cancelScheduledValues(t);
  }
  dispose(){for(const o of [this.vco,this.sub]){try{o.stop();}catch{}}this.output.disconnect();}
}
