export const clamp=(n,min,max)=>Math.min(max,Math.max(min,n));
export function cutoffToHz(value){return 65*Math.pow(115,clamp(value,0,1));}
export function resonanceToQ(value){return 0.7+Math.pow(clamp(value,0,1),2.15)*22;}

// Gentler resonant peak when two low-pass pole pairs are cascaded.
export function resonanceTo303Q(value){return 0.72+Math.pow(clamp(value,0,1),1.65)*9.5;}
